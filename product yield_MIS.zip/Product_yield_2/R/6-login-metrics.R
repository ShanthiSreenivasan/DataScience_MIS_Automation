loginfo("Product Yield MIS - 6-login-metrics.R Started")

compute_login_metrics <- function(data) {
  
  data[, .(
  `Total Logins` = .N,
  `New Logins` = sum(has_repeat_login == 0),
  `Repeat Logins` = sum(has_repeat_login == 1),
  `Unique Logins` = n_distinct(user_id),
  `New Unique Logins` = n_distinct(user_id[has_repeat_login == 0]),
  `Repeat Unique Logins` = n_distinct(user_id[has_repeat_login == 1]),
  
  `Mobile Logins` = sum(is_android_login == 1),
  `New Mobile Logins` = sum(is_android_login == 1 & has_repeat_login == 0),
  `Repeat Mobile Logins` = sum(is_android_login == 1 & has_repeat_login == 1),
  `Unique Mobile Logins` = n_distinct(user_id[is_android_login == 1]),
  `New Unique Mobile Logins` = n_distinct(user_id[is_android_login == 1 & has_repeat_login == 0]),
  `Repeat Unique Mobile Logins` = n_distinct(user_id[is_android_login == 1 & has_repeat_login == 1])
  )]
  
}


#*******************************************************************************
#*******************************************************************************
## 1. Get Data =======
#*******************************************************************************
#*******************************************************************************

loginfo("Product Yield MIS - 6-login-metrics.R Login Metrics DTD Query Started")
start_time <- Sys.time()
query = 'login-metrics.sql'

login_metrics_dump <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/login-metrics.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),MONTH_START_DATE = MONTH_START)
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 6-login-metrics.R Login Metrics Dump query Completed")


#*******************************************************************************
#*******************************************************************************
## 2. Compute Metrics =======
#*******************************************************************************
#*******************************************************************************
login_metrics_daily <- login_metrics_dump %>%
                      .[login_date >= DATE] %>%
                      rollup_dt('customer_type', compute_login_metrics, 'Total') %>%
                      rename(`Customer Type` = customer_type)

login_metrics_mtd <- login_metrics_dump %>%
                     rollup_dt('customer_type', compute_login_metrics, 'Total') %>%
                     rename(`Customer Type` = customer_type)


LOGIN_METRICS <- full_join(
  gather(login_metrics_daily, Metric, Daily, -`Customer Type`),
  gather(login_metrics_mtd, Metric, MTD, -`Customer Type`)
) %>% 
  select(Metric, `Customer Type`, Daily, MTD)

repeat_login_metrics_daily <- login_metrics_dump %>%
                              .[login_date >= DATE] %>%
                              group_by (channel,customer_type) %>%
                              summarise(`Daily` = n_distinct(user_id[has_repeat_login == 1])) %>%
                              rename (Channel = channel, `Customer Type` = customer_type)

repeat_login_metrics_mtd <- login_metrics_dump %>%
                            group_by (channel,customer_type) %>%
                            summarise(`MTD` = n_distinct(user_id[has_repeat_login == 1])) %>%
                            rename (Channel = channel, `Customer Type` = customer_type)

REPEAT_LOGIN_METRICS <- full_join(
  repeat_login_metrics_daily,
  repeat_login_metrics_mtd
) %>% 
  select(Channel, `Customer Type`, Daily, MTD)

# Vintage
elapsed_months <- function(end_date, start_date) {
  ed <- as.POSIXlt(end_date)
  sd <- as.POSIXlt(start_date)
  12 * (ed$year - sd$year) + (ed$mon - sd$mon)
}

Unique_login_vintage <- login_metrics_dump %>% 
  mutate(
    month_diff = elapsed_months(login_metrics_dump$login_date, login_metrics_dump$first_profile_date)
  ) %>% 
  filter(!is.na(month_diff)) %>% 
  mutate(
    vintage = case_when(
      (month_diff >= 0 & month_diff <= 1) ~ 'V0',
      (month_diff >= 2 & month_diff <= 5) ~ 'V1',
      T ~ 'V2'
    )
  ) %>% 
  as.data.table() 

Unique_login_vintage_daily <- Unique_login_vintage %>% 
  .[login_date >= DATE] %>%
  group_by (vintage,customer_type) %>% 
  summarise(`Daily` = n_distinct(user_id[!is.na(customer_type)])) %>% 
  
  rename (Vintage = vintage, `Customer Type` = customer_type)

Unique_login_vintage_mtd <- Unique_login_vintage %>% 
  group_by (vintage,customer_type) %>%
  summarise(`MTD` = n_distinct(user_id[!is.na(customer_type)])) %>% 
  rename (Vintage = vintage, `Customer Type` = customer_type)

UNIQUE_LOGIN_VINTAGE_METRICS <- full_join(
  Unique_login_vintage_daily,
  Unique_login_vintage_mtd
) %>% 
  group_by(Vintage) %>% 
  select(Vintage, `Customer Type`, Daily, MTD)

# Red Nsaleable Logins
red_salebale_login_metrics_daily <- login_metrics_dump %>%
  .[login_date >= DATE & customer_type == 'Red' & nsaleable > 0] %>%
  group_by (channel,customer_type) %>%
  summarise(`Daily` = n_distinct(user_id[has_repeat_login == 1])) %>%
  rename (Channel = channel, `Customer Type` = customer_type)

red_salebale_login_metrics_mtd <- login_metrics_dump %>%
  .[login_date >= MONTH_START &customer_type == 'Red' & nsaleable > 0] %>%
  group_by (channel,customer_type) %>%
  summarise(`MTD` = n_distinct(user_id[has_repeat_login == 1])) %>%
  rename (Channel = channel, `Customer Type` = customer_type)

RED_SALEABLE_LOGIN_METRICS <- full_join(
  red_salebale_login_metrics_daily,
  red_salebale_login_metrics_mtd
) %>% 
  select(Channel, `Customer Type`, Daily, MTD)
