loginfo("Product Yield MIS - 5-bys-funnel.R Started")


#*******************************************************************************
#*******************************************************************************
## 1. BYS New Funnel =======
#*******************************************************************************
#*******************************************************************************

#' Funnel for Amber customers who were newly profiled this month. 
#' Looks at performance through 040, 050 and 070.
# 
start_time <- Sys.time()
query = 'bys-new-funnel-old.sql - DTD'

bys_funnel_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-new-funnel-old.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'Daily', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'bys-new-funnel-old.sql - MTD'

bys_funnel_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-new-funnel-old.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'MTD', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_M0_FUNNEL<-tryCatch(BYS_M0_FUNNEL <- full_join(bys_funnel_dtd, bys_funnel_mtd)
         ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),MTD=numeric(0)))


#*******************************************************************************
#*******************************************************************************
## 2. BYS Visits Funnel =======
#*******************************************************************************
#*******************************************************************************

#' Funnel for customers who have visited the BYS 040 / prepayment page in this 
#' day/month
start_time <- Sys.time()
query = 'bys-visits-funnel-old.sql - DTD'

bys_visits_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-visits-funnel-old.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'Daily', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'bys-visits-funnel-old.sql - MTD'

bys_visits_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-visits-funnel-old.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'MTD', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_VISITS_FUNNEL<-tryCatch(BYS_VISITS_FUNNEL <- full_join(bys_visits_dtd, bys_visits_mtd)
,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),MTD=numeric(0)))
  
loginfo("Product Yield MIS - 5-bys-funnel.R BYS Visits completed")
