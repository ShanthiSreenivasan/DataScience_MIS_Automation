#' BHR Funnel MTD


bhr_subscriptions <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhr-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>%
  left_join(OIC_LIST, by = c('sub_oic' = 'oic')) %>%
  mutate(team = case_when(
    !is.na(team) ~ team,
    !sub_oic %in% c('System', 'PORTFOLIO') ~ 'Assisted-Others',
    T ~ sub_oic
  )) %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL')) 




BHR_SUBSCRIPTIONS <- tryCatch(bhr_subscriptions %>%
                                rollup_dt(c('service_type', 'customer_type'), function(data) {
                                  data[, .(
                                    `Assisted` = sum(!sub_oic %in% c('System', 'PORTFOLIO', 'andriodApp', 'androidApp')),
                                    `System` = sum(sub_oic == 'System'),
                                    `PA` = sum(sub_oic == 'PORTFOLIO'),
                                    Total = .N
                                  )]
                                }, 'Total') %>%
                                rename(`Service Type` = service_type, `Customer Type` = customer_type), 
                              error = function(e) data.frame(`Service Type` = character(0),
                                                             `Customer Type` = character(0),
                                                             'Assisted' = character(0),
                                                             'System' = character(0),
                                                             'PA' = character(0),
                                                             'Total' = character(0))) 

BHR_SUBSCRIPTIONS_AGENCYWISE <- tryCatch(bhr_subscriptions %>%
                                           rollup_dt(c('service_type', 'customer_type', 'team'), function(data) {
                                             data[, .(
                                               Total = .N
                                             )]
                                           }, 'Total') %>%
                                           rename(`Service Type` = service_type, `Customer Type` = customer_type, Team = team),
                                         error = function(e) data.frame(`Service Type` = character(0),
                                                                        `Customer Type` = character(0),
                                                                        'Team' = character(0),
                                                                        'Total' = character(0)))


# DTD
bhr_subscriptions_dtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhr-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  left_join(OIC_LIST, by = c('sub_oic' = 'oic')) %>%
  mutate(team = case_when(
    !is.na(team) ~ team,
    !sub_oic %in% c('System', 'PORTFOLIO') ~ 'Assisted-Others',
    T ~ sub_oic
  )) %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL')) 




BHR_SUBSCRIPTIONS_DTD <- tryCatch(bhr_subscriptions_dtd %>%
                                    rollup_dt(c('service_type', 'customer_type'), function(data) {
                                      data[, .(
                                        `Assisted` = sum(!sub_oic %in% c('System', 'PORTFOLIO', 'andriodApp', 'androidApp')),
                                        `System` = sum(sub_oic == 'System'),
                                        `PA` = sum(sub_oic == 'PORTFOLIO'),
                                        Total = .N
                                      )]
                                    }, 'Total') %>%
                                    rename(`Service Type` = service_type, `Customer Type` = customer_type), 
                                  error = function(e) data.frame(`Service Type` = character(0),
                                                                 `Customer Type` = character(0),
                                                                 'Assisted' = character(0),
                                                                 'System' = character(0),
                                                                 'PA' = character(0),
                                                                 'Total' = character(0))) 

BHR_SUBSCRIPTIONS_AGENCYWISE_DTD <- tryCatch(bhr_subscriptions_dtd %>%
                                               rollup_dt(c('service_type', 'customer_type', 'team'), function(data) {
                                                 data[, .(
                                                   Total = .N
                                                 )]
                                               }, 'Total') %>%
                                               rename(`Service Type` = service_type, `Customer Type` = customer_type, Team = team),
                                             error = function(e) data.frame(`Service Type` = character(0),
                                                                            `Customer Type` = character(0),
                                                                            'Team' = character(0),
                                                                            'Total' = character(0)))


###################################################################################
################ BHR Visits and BHRL Visits Yield#########################################
###################################################################################

tdt <- function(inpdt){
  transposed <- t(inpdt[,-1,with=F]);
  colnames(transposed) <- inpdt[[1]];
  transposed <- data.table(transposed, keep.rownames=T);
  setnames(transposed, 1, names(inpdt)[1]);
  return(transposed);
}


########################## BHR Funnel MTD ####################################

start_time <- Sys.time()
query = 'bhr-visits-funnel.sql'

bhr_visits_mtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhr-visits-funnel.sql'),
  list(START_DATE = MONTH_START,VAR = 'MTD', END_DATE = DATE + days(1))
)) %>% 
  tdt() %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL'))

if(nrow(bhr_visits_mtd) == 0){
  bhr_visits_mtd = data.table(`BHR_VISITS_MTD` = character(0))
}

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 9-bhr-funnel.R Query completed")

########################## BHR Funnel DTD ####################################
start_time <- Sys.time()
query = 'bhr-visits-funnel.sql'

bhr_visits_dtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhr-visits-funnel.sql'),
  list(START_DATE = DATE,VAR = 'DTD', END_DATE = DATE + days(1))
)) %>% 
  tdt() %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL'))

if(nrow(bhr_visits_dtd) == 0){
  bhr_visits_dtd = data.table(`BHR_VISITS_DTD` = character(0))
}

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 9-bhr-funnel.R Query completed")

bhr_visits <- merge(x=bhr_visits_dtd,y=bhr_visits_mtd,by="Metrics",sort=F)


##############################################################################
########################### BHRL MTD #########################################

start_time <- Sys.time()
query = 'bhrl-visits-funnel.sql'

bhrl_visits_mtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhrl-visits-funnel.sql'),
  list(START_DATE = MONTH_START,VAR = 'MTD' ,END_DATE = DATE + days(1))
)) %>% 
  tdt() %>%
  as.data.table() , error = function(e) data.frame('BHRL_SUBSCRIPTION' = 'NULL'))


if(nrow(bhrl_visits_mtd) == 0){
  bhrl_visits_mtd = data.table(`BHRL_VISITS_MTD` = character(0))
}

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 9-bhr-funnel.R Query completed")

########################### BHRL DTD #########################################
start_time <- Sys.time()
query = 'bhrl-visits-funnel.sql'

bhrl_visits_dtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhrl-visits-funnel.sql'),
  list(START_DATE = DATE,VAR = 'DTD' ,END_DATE = DATE + days(1))
)) %>% 
  tdt() %>%
  as.data.table() , error = function(e) data.frame('BHRL_SUBSCRIPTION' = 'NULL'))


if(nrow(bhrl_visits_dtd) == 0){
  bhrl_visits_dtd = data.table(`BHRL_VISITS_DTD` = character(0))
}

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 9-bhr-funnel.R Query completed")


bhrl_visits <- merge(x=bhrl_visits_dtd,y=bhrl_visits_mtd,by="Metrics",sort=F)

