#' BHRL Funnel MTD


bhrl_subscriptions <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhrl-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>%
  left_join(OIC_LIST, by = c('sub_oic' = 'oic')) %>%
  mutate(team = case_when(
    !is.na(team) ~ team,
    !sub_oic %in% c('System', 'PORTFOLIO') ~ 'Assisted-Others',
    T ~ sub_oic
  )) %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL')) 




BHRL_SUBSCRIPTIONS <- tryCatch(bhrl_subscriptions %>%
  rollup_dt(c('service_type', 'customer_type'), function(data) {
    data[, .(
      `Assisted` = sum(!sub_oic %in% c('System', 'PORTFOLIO', 'andriodApp', 'androidApp')),
      `System` = sum(sub_oic == 'System'),
      `PA` = sum(sub_oic == 'PORTFOLIO'),
      Total = .N
    )]
  }, 'Total') %>%
  rename(`Service Type` = service_type, `Customer Type` = customer_type), 
error = function(e) data.frame(`Service Type` = character(0),
                               `Customer Type` = character(0),
                               'Assisted' = character(0),
                               'System' = character(0),
                               'PA' = character(0),
                               'Total' = character(0))) 

BHRL_SUBSCRIPTIONS_AGENCYWISE <- tryCatch(bhrl_subscriptions %>%
   rollup_dt(c('service_type', 'customer_type', 'team'), function(data) {
     data[, .(
       Total = .N
     )]
   }, 'Total') %>%
   rename(`Service Type` = service_type, `Customer Type` = customer_type, Team = team),
 error = function(e) data.frame(`Service Type` = character(0),
                                `Customer Type` = character(0),
                                'Team' = character(0),
                                'Total' = character(0)))


# DTD
bhrl_subscriptions_dtd <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bhrl-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  left_join(OIC_LIST, by = c('sub_oic' = 'oic')) %>%
  mutate(team = case_when(
    !is.na(team) ~ team,
    !sub_oic %in% c('System', 'PORTFOLIO') ~ 'Assisted-Others',
    T ~ sub_oic
  )) %>%
  as.data.table() , error = function(e) data.frame('BHR_SUBSCRIPTION' = 'NULL')) 




BHRL_SUBSCRIPTIONS_DTD <- tryCatch(bhrl_subscriptions_dtd %>%
  rollup_dt(c('service_type', 'customer_type'), function(data) {
    data[, .(
      `Assisted` = sum(!sub_oic %in% c('System', 'PORTFOLIO', 'andriodApp', 'androidApp')),
      `System` = sum(sub_oic == 'System'),
      `PA` = sum(sub_oic == 'PORTFOLIO'),
      Total = .N
    )]
  }, 'Total') %>%
  rename(`Service Type` = service_type, `Customer Type` = customer_type), 
error = function(e) data.frame(`Service Type` = character(0),
                               `Customer Type` = character(0),
                               'Assisted' = character(0),
                               'System' = character(0),
                               'PA' = character(0),
                               'Total' = character(0))) 

BHRL_SUBSCRIPTIONS_AGENCYWISE_DTD <- tryCatch(bhrl_subscriptions_dtd %>%
 rollup_dt(c('service_type', 'customer_type', 'team'), function(data) {
   data[, .(
     Total = .N
   )]
 }, 'Total') %>%
 rename(`Service Type` = service_type, `Customer Type` = customer_type, Team = team),
error = function(e) data.frame(`Service Type` = character(0),
                              `Customer Type` = character(0),
                              'Team' = character(0),
                              'Total' = character(0)))


