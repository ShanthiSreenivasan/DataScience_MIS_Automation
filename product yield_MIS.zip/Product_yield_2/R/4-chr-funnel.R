loginfo("Product Yield MIS - 4-chr-funnel.R Started")

loginfo("Product Yield MIS - CHR YIELD and VISITS STARTED")

#*******************************************************************************
#*******************************************************************************
## 1. Get Data =======
#*******************************************************************************
#*******************************************************************************


loginfo("Product Yield MIS - 4-chr-funnel.R Query started")
start_time <- Sys.time()
query = 'chr-funnel-old.sql'

chr_raw <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-funnel-old.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 4-chr-funnel.R Query completed")


#*******************************************************************************
#*******************************************************************************
## 2. Process =======
#*******************************************************************************
#*******************************************************************************
filter_funnel <- function(data, date_filter) {
  data[undecided_if_assisted == F &
         pp_if_assisted == F &
         pg_if_assisted == F &
         paid_if_assisted == F] %>% 
    gather(date_type, value, matches("_date")) %>% 
    mutate(date_type = factor(date_type, c("paid_date", "pg_date", "pp_date",
                                           "undecided_date", "profiled_date"),
                              ordered = T)) %>% 
    group_by(user_id) %>% 
    filter(all(date_filter(value), na.rm = T)) %>% 
    spread(date_type, value) %>% 
    data.table
}

compute_funnel <- function(data, funnel_cols) {
  result <- data %>% 
    summarise_each(funs(sum(!is.na(.))), matches("_date")) %>% 
    set_colnames(rev(funnel_cols)) %>%
    gather(Metric, Counts) %>% 
    mutate(Metric = factor(Metric, rev(funnel_cols), ordered = T)) %>% 
    arrange(desc(Metric)) %>% 
    mutate(Dropoff = round(Counts / lag(Counts, default = max(Counts)) * 100, 0)) %>% 
    mutate(Funnel = round(Counts / max(Counts) * 100, 0)) 
  
  return(result)
}

chr_raw %<>%
  mutate_each(funs(ifelse(is.na(.), F, .)), matches("if_assisted")) %>% 
  mutate_each(funs(ymd_hms), matches("_date")) %>% 
  data.table


FUNNEL_ITEMS <- c("Profiled", "Undecided - 000", "Prepayment - 040",
                  "PG - 050", "Paid - 070")

CHR_CD_FUNNEL_RED <- tryCatch(CHR_CD_FUNNEL_RED <-chr_raw %>% .[customer_type == 'Red'] %>%
  filter_funnel(DATE_FILTERS[["daily"]]) %>% 
  compute_funnel(FUNNEL_ITEMS) %>% 
  select(Metric, Daily = Counts, `Daily Dropoff %` = Dropoff)
  ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),`Daily Dropoff %`=numeric(0)))

CHR_MTD_FUNNEL_RED <- tryCatch(CHR_MTD_FUNNEL_RED <-chr_raw %>% .[customer_type == 'Red'] %>%
  filter_funnel(DATE_FILTERS[["mtd"]]) %>% 
  compute_funnel(FUNNEL_ITEMS) %>% 
  select(Metric, MTD = Counts, `MTD Dropoff %` = Dropoff)
  ,error = function(e) data.frame(Metric = character(0),MTD=numeric(0),`MTD Dropoff %`=numeric(0)))
  
CHR_FUNNEL_RED<-tryCatch(CHR_FUNNEL_RED <- full_join(CHR_CD_FUNNEL_RED, CHR_MTD_FUNNEL_RED)
                         ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),`Daily Dropoff %`=numeric(0),MTD=numeric(0),`MTD Dropoff %`=numeric(0)))
                          
CHR_CD_FUNNEL_GREEN <- tryCatch(CHR_CD_FUNNEL_GREEN <-chr_raw %>% .[customer_type == 'Green'] %>%
filter_funnel(DATE_FILTERS[["daily"]]) %>% 
  compute_funnel(FUNNEL_ITEMS) %>% 
  select(Metric, Daily = Counts, `Daily Dropoff %` = Dropoff)
,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),`Daily Dropoff %`=numeric(0)))

CHR_MTD_FUNNEL_GREEN <- tryCatch(CHR_MTD_FUNNEL_GREEN<-chr_raw %>% .[customer_type == 'Green'] %>%
filter_funnel(DATE_FILTERS[["mtd"]]) %>% 
  compute_funnel(FUNNEL_ITEMS) %>% 
  select(Metric, MTD = Counts, `MTD Dropoff %` = Dropoff)
,error = function(e) data.frame(Metric = character(0),MTD=numeric(0),`MTD Dropoff %`=numeric(0)))

CHR_FUNNEL_GREEN<-tryCatch(CHR_FUNNEL_GREEN <- full_join(CHR_CD_FUNNEL_GREEN, CHR_MTD_FUNNEL_GREEN)
         ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),`Daily Dropoff %`=numeric(0),MTD=numeric(0),`MTD Dropoff %`=numeric(0)))

#*******************************************************************************
#*******************************************************************************
## . CHR Visits Funnel =======
#*******************************************************************************
#*******************************************************************************

loginfo("Product Yield MIS - 4-chr-funnel.R Visits Query started")
start_time <- Sys.time()
query = 'chr-visits-funnel-old.sql'

chr_visits_raw <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-visits-funnel-old.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 4-chr-funnel.R Visits Query Completed")
#******************************************************************************

chr_visits_raw[, chr_visit_date := ymd_hms(chr_visit_date)]

CHR_VISITS_DAILY_RED_FUNNEL <-tryCatch(CHR_VISITS_DAILY_RED_FUNNEL<- chr_visits_raw %>% 
  .[customer_type == 'Red'] %>%
  .[as_date(chr_visit_date) == DATE,
    .(
      chr_visited = max(chr_visited),  
      pay_now = max(pay_now),
      made_payment = max(made_payment)
    ),
    user_id
  ] %>% 
  .[, .(
    `CHR Page Visits - 040` = sum(chr_visited),
    `Payment Page - 050` = sum(pay_now),
    `Payment Page Dropoff%` = as_perc(100 - perc_bin(pay_now[chr_visited == 1])),
    `Payment Made - 070` = sum(made_payment),
    `Payment Made Dropoff%` = as_perc(100 - perc_bin(made_payment[pay_now == 1]))
    )]
  ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0)))


CHR_VISITS_DAILY_RED_FUNNEL <- tryCatch(CHR_VISITS_DAILY_RED_FUNNEL<-
  gather(CHR_VISITS_DAILY_RED_FUNNEL, Metric, Daily)
  ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0)))

CHR_VISITS_MTD_RED_FUNNEL <- tryCatch(CHR_VISITS_MTD_RED_FUNNEL  <-chr_visits_raw %>% 
  .[customer_type == 'Red'] %>%
  .[is.within.mtd(as_date(chr_visit_date), DATE),
    .(
      chr_visited = max(chr_visited),  
      pay_now = max(pay_now),
      made_payment = max(made_payment)
    ),
    user_id
  ] %>% 
  .[, .(
    `CHR Page Visits - 040` = sum(chr_visited),
    `Payment Page - 050` = sum(pay_now),
    `Payment Page Dropoff%` = as_perc(100 - perc_bin(pay_now[chr_visited == 1])),
    `Payment Made - 070` = sum(made_payment),
    `Payment Made Dropoff%` = as_perc(100 - perc_bin(made_payment[pay_now == 1]))
    )]
  ,error = function(e) data.frame(Metric = character(0),MTD=numeric(0)))

CHR_VISITS_MTD_RED_FUNNEL <- tryCatch(CHR_VISITS_MTD_RED_FUNNEL  <-
  gather(CHR_VISITS_MTD_RED_FUNNEL, Metric, MTD)
  ,error = function(e) data.frame(Metric = character(0),MTD=numeric(0)))

CHR_VISITS_RED_FUNNEL <-tryCatch(CHR_VISITS_RED_FUNNEL <- full_join(CHR_VISITS_DAILY_RED_FUNNEL, CHR_VISITS_MTD_RED_FUNNEL)
         ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),MTD=numeric(0)))

CHR_VISITS_DAILY_GREEN_FUNNEL <-tryCatch(CHR_VISITS_DAILY_GREEN_FUNNEL  <- chr_visits_raw %>% 
.[customer_type == 'Green'] %>%
.[as_date(chr_visit_date) == DATE,
  .(
    chr_visited = max(chr_visited),  
    pay_now = max(pay_now),
    made_payment = max(made_payment)
  ),
  user_id
  ] %>% 
  .[, .(
    `CHR Page Visits - 040` = sum(chr_visited),
    `Payment Page - 050` = sum(pay_now),
    `Payment Page Dropoff%` = as_perc(100 - perc_bin(pay_now[chr_visited == 1])),
    `Payment Made - 070` = sum(made_payment),
    `Payment Made Dropoff%` = as_perc(100 - perc_bin(made_payment[pay_now == 1]))
  )]
,error = function(e) data.frame(Metric = character(0),Daily=numeric(0)))


CHR_VISITS_DAILY_GREEN_FUNNEL <- tryCatch(CHR_VISITS_DAILY_GREEN_FUNNEL  <-
  gather(CHR_VISITS_DAILY_GREEN_FUNNEL, Metric, Daily)
  ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0)))

CHR_VISITS_MTD_GREEN_FUNNEL <-tryCatch(CHR_VISITS_MTD_GREEN_FUNNEL  <- chr_visits_raw %>% 
.[customer_type == 'Green'] %>%
.[is.within.mtd(as_date(chr_visit_date), DATE),
  .(
    chr_visited = max(chr_visited),  
    pay_now = max(pay_now),
    made_payment = max(made_payment)
  ),
  user_id
  ] %>% 
  .[, .(
    `CHR Page Visits - 040` = sum(chr_visited),
    `Payment Page - 050` = sum(pay_now),
    `Payment Page Dropoff%` = as_perc(100 - perc_bin(pay_now[chr_visited == 1])),
    `Payment Made - 070` = sum(made_payment),
    `Payment Made Dropoff%` = as_perc(100 - perc_bin(made_payment[pay_now == 1]))
  )]
,error = function(e) data.frame(Metric = character(0),MTD=numeric(0)))


CHR_VISITS_MTD_GREEN_FUNNEL <- tryCatch(CHR_VISITS_MTD_GREEN_FUNNEL  <-
  gather(CHR_VISITS_MTD_GREEN_FUNNEL, Metric, MTD)
      ,error = function(e) data.frame(Metric = character(0),MTD=numeric(0)))

CHR_VISITS_GREEN_FUNNEL<-tryCatch(CHR_VISITS_GREEN_FUNNEL <- full_join(CHR_VISITS_DAILY_GREEN_FUNNEL, CHR_VISITS_MTD_GREEN_FUNNEL)
         ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),MTD=numeric(0)))

loginfo("Product Yield MIS - CHR YIELD and VISITS COMPLETED")
