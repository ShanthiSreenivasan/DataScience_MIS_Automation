#' The CIS Funnel looks at how a new red profiled customer proceeds through the
#' various stages without assistance and where the dropoff happens. 
#' 
#' For the Daily Funnel, only red profiled customers of that day and their 
#' associated movements on the same day is to be considered. Also, only movements
#' without any assistance (without any OIC touch) is to be considered.
#' 
#' Same goes for the MTD Funnel
#' 
#' Note: An assistance is considered as a Non-NC/RNR CRM Status Change. Anything
#' apart from that is considered to be non-assisted.


loginfo("Product Yield MIS - 2-cis-funnel.R Started")
#*******************************************************************************
#*******************************************************************************
## 1. Get Data =======
#*******************************************************************************
#*******************************************************************************
start_time <- Sys.time()
query = 'cis-funnel.sql - DTD'

cis_funnel_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/cis-funnel.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'Daily', names(.))

try(logs_to_db(query, start_time))
#*******************************************************************************
start_time <- Sys.time()
query = 'cis-funnel.sql - MTD'

cis_funnel_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/cis-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'MTD', names(.))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 2-cis-funnel.R Query Done")

CIS_M0_FUNNEL <-tryCatch(CIS_M0_FUNNEL <- full_join(cis_funnel_dtd, cis_funnel_mtd)
          ,error = function(e) data.frame(Metric = character(0),Daily=numeric(0),MTD=numeric(0)))

loginfo("Product Yield MIS - 2-cis-funnel.R Query completed")
#*******************************************************************************

loginfo("Product Yield MIS - 2-cis-funnel.R Done")

# write_excel_table(wb, 'ARS Flow Status - Full Payments', ARS_FLOW_FUNNEL_DTD, 3, 3, 'ARS Full Payment Visits - DTD')
# write_excel_table(wb, 'ARS Flow Status - Full Payments', ARS_FLOW_FUNNEL_MTD, 3 + nrow(ARS_FLOW_FUNNEL_DTD) + 3, 3, 'ARS Full Payment Visits - MTD')


#*******************************************************************************
#*******************************************************************************
## 2. Process =======
#*******************************************************************************
#*******************************************************************************

filter_funnel <- function(data, date_filter) {
  data[undecided_if_assisted == F &
     pp_if_assisted == F &
     pg_if_assisted == F &
     paid_if_assisted == F] %>% 
    gather(date_type, value, matches("_date")) %>% 
    mutate(date_type = factor(date_type, c("paid_date", "pg_date", "pp_date",
                                           "undecided_date", "profiled_date"),
                              ordered = T)) %>% 
    group_by(user_id) %>% 
    filter(all(date_filter(value), na.rm = T)) %>% 
    spread(date_type, value) %>% 
    data.table
}

compute_funnel <- function(data, funnel_cols) {
  result <- data %>% 
    summarise_each(funs(sum(!is.na(.))), matches("_date")) %>% 
    set_colnames(rev(funnel_cols)) %>%
    gather(Metric, Counts) %>% 
    mutate(Metric = factor(Metric, rev(funnel_cols), ordered = T)) %>% 
    arrange(desc(Metric)) %>% 
    mutate(Dropoff = round(Counts / lag(Counts, default = max(Counts)) * 100, 0)) %>% 
    mutate(Funnel = round(Counts / max(Counts) * 100, 0)) 
    
  return(result)
}

FUNNEL_ITEMS <- c("Profiled", "Undecided - 000", "Prepayment - 040", "PG - 050",
                  "CIS Paid - 070")

#*******************************************************************************
#*******************************************************************************
## 2. CIS Visits Funnel =======
#*******************************************************************************
#*******************************************************************************

# loginfo("Product Yield MIS - 2-cis-funnel.R Visits Query DTD Started")
# # 
# # # Trancate Table
# loginfo('Product Yield MIS - CIS VISIT Funnel  DTD Table  - Initiated')
# dbGetQuery(get_conn(), 'TRUNCATE ONLY test.cis_visit_funnel')
# dbDisconnect(get_conn())
# 
# data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/cis-visit-funnel-table.sql'),
#   list(START_DATE = DATE, END_DATE = DATE + days(1))
# ))
# 
# loginfo('Product Yield MIS - CIS VISIT Funnel DTD Table  - Completed')
# 
# cis_visits_dtd <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/cis-visits-funnel.sql'),
#   list(START_DATE = DATE, END_DATE = DATE + days(1))
# )) %>%
#   gather_('Metric', 'Daily', names(.))
# 
# 
# loginfo("Product Yield MIS - 2-cis-funnel.R Visits Query DTD Done")
# # #*******************************************************************************
# loginfo("Product Yield MIS - 2-cis-funnel.R Visits Query MTD Started")
# # 
# # Trancate Table
# loginfo('Product Yield MIS - CIS VISIT Funnel  MTD Table  - Initiated')
# dbGetQuery(get_conn(), 'TRUNCATE ONLY test.cis_visit_funnel')
# dbDisconnect(get_conn())
# 
# data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/cis-visit-funnel-table.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
# ))
# 
# loginfo('Product Yield MIS - CIS VISIT Funnel MTD Table  - Completed')
# 
# cis_visits_mtd <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/cis-visits-funnel.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
# )) %>%
#   gather_('Metric', 'MTD', names(.))
# 
# loginfo("Product Yield MIS - 2-cis-funnel.R Visits Query Done")
# #*******************************************************************************
# 
# CIS_VISITS_FUNNEL <- full_join(cis_visits_dtd, cis_visits_mtd)
# 
# loginfo("Product Yield MIS - 2-cis-funnel.R Completed")

