setwd(Sys.getenv('CM_REPORTS_FOLDER'))
rm(list = ls())
MIS_NAME = 'PRODUCT YIELD MIS 2'

library(magrittr)
library(dplyr)
library(purrr)
library(tidyr)
library(stringr)
library(lubridate)
library(data.table)
#library(ggplot2)
library(DBI)
library(RPostgreSQL)
library(logging)
library(mailR)
library(xtable)
library(yaml)

DATE <- ymd(Sys.Date()-1)
MONTH_START <- floor_date(DATE, "months")
NXT_MONTH_START <- floor_date(DATE, "months") + days(31)
NXT_DTD_START <- ymd(Sys.Date() - 1) + days(31)

MIS_PATH <- "reports/Product_yield_2"
DATA_PATH <- file.path(Sys.getenv('DATA_PATH'), str_interp("cm-reports-data/${DATE}"))
dir.create(DATA_PATH, recursive = T)

args <- commandArgs(trailingOnly = T)

if (length(args) != 0 && args[1] == '--PROD') {
  DATE <- ymd(Sys.Date() - 1)
  TEST <- FALSE
} else {
  TEST <- TRUE
}

basicConfig()
LOGS_PATH <- file.path(Sys.getenv('LOGS_PATH'), str_interp('${DATE}'))
dir.create(LOGS_PATH, recursive = T)
addHandler(writeToFile, file = file.path(LOGS_PATH, "product-yield-mis-2.log"))
loginfo("Product Yield MIS 2 Initiated")

source("reports/utility-functions.R")
source("reports/excel-utilities.R")

options(error = err_func)

DBCONFIG <- yaml.load_file("config/dbconfig.yaml")$warehouse
S3CONFIG <- yaml.load_file("config/dbconfig.yaml")$s3bucket
MailConfig <- yaml.load_file("config/mail_list.yaml")

Sys.setenv(
  "AWS_ACCESS_KEY_ID" = S3CONFIG$AWS_ACCESS_KEY_ID,
  "AWS_SECRET_ACCESS_KEY" = S3CONFIG$AWS_SECRET_ACCESS_KEY,
  "AWS_DEFAULT_REGION" = S3CONFIG$AWS_DEFAULT_REGION
)

#' S3 key to use for writing data files
REPORTS_BUCKET <- get_bucket('cm-misc-reports')
REPORTS_KEY <- str_interp('cm-misc-reports')

DAYS_IN_MONTH <- as.numeric(days_in_month(DATE))
DAYS_PAST <- day(DATE)
DAYS_LEFT <- DAYS_IN_MONTH - DAYS_PAST

DATE_FILTERS <- list(
  "daily" = function(date) as_date(date) == DATE,
  "mtd" = function(date) is.within.mtd(as_date(date), DATE),
  "prev_month" = function(date) date %within% interval(
    floor_subtract_month(DATE, 1), ceiling_subtract_month(DATE, 1)),
  "within_4months" = function(date) as_date(date) >= floor_subtract_month(DATE, 4),
  "greater_4months" = function(date) as_date(date) < floor_subtract_month(DATE, 4),
  "default" = function(date) T
)

PLAN_NUMBERS <- fread("config/plan_targets/PRODUCT_YIELD_TARGETS.csv")


REFERRALS_OICS <- fread('config/oic_targets/REFERRALS_OIC_MASTER_LIST.csv')[is_active == 1, .(oic, team)]
CIS_OICS <- fread('config/oic_targets/CIS_OIC_MASTER_LIST.csv')[is_active == 1, .(oic, team)]
OIC_LIST <- bind_rows(REFERRALS_OICS, CIS_OICS) %>%
  distinct(oic, .keep_all = T)

# Create sheets
#lapply(sheet_names, function(sheet) addWorksheet(wb, sheet))

output_filename <- file.path(DATA_PATH, str_interp("Product Yield Report 2 - ${DATE}.xlsx"))

get_conn <- function () {
  dbConnect(
    PostgreSQL(),
    port = DBCONFIG$port,
    user = DBCONFIG$username,
    password = DBCONFIG$password,
    dbname = DBCONFIG$db,
    host = DBCONFIG$host
  )
}

#Refresh usl_currentmonth table
#dbGetQuery(get_conn(), "REFRESH MATERIALIZED VIEW usl_currentmonth")

source(file.path(MIS_PATH, "R/6-login-metrics.R"))
source(file.path(MIS_PATH, "R/2-cis-funnel.R"))
source(file.path(MIS_PATH, "R/4-chr-funnel.R"))
source(file.path(MIS_PATH, "R/5-bys-funnel.R"))
# source(file.path(MIS_PATH, "R/6-login-metrics.R"))


loginfo("Product Yield MIS 2 - All Computations Completed.")
prod_env <- file.path(DATA_PATH, str_interp("Product Yield MIS 2 - ${DATE}.RData"))
save.image(prod_env)

MARKETING_BUCKET <- 'cm-marketing-reports'
MARKETING_KEY <- 'cm-marketing-reports'

aws.s3::put_object(
  file = prod_env,
  bucket = MARKETING_BUCKET,
  object = file.path(MARKETING_KEY, basename(prod_env))
)
#******************************************************
## 1.3 Export to Excel =======
#******************************************************

#' Adjust column widths
# lapply(sheet_names, function(sheet)
#   setColWidths(wb, sheet, cols = 1:120, widths = "auto", ignoreMergedCells = T)
# )
# 
# saveWorkbook(wb, output_filename, overwrite = T)
# aws.s3::put_object(
#   file = output_filename,
#   bucket = REPORTS_BUCKET,
#   object = file.path(REPORTS_KEY, basename(output_filename))
# )

loginfo("Product Yield MIS 2 - Excel file exported and uploaded to S3")

#*******************************************************************************
#*******************************************************************************
## 2. Email  =======
#*******************************************************************************
#*******************************************************************************

sender = MailConfig$Datascience
recipients1 = c(MailConfig$Referral_BU,
               MailConfig$Assitted_channel$common,
               MailConfig$Assitted_channel$ref,
               MailConfig$Assitted_channel$tnq,
               'ranjitpunja@creditmantri.com',
               'productengineering-bas@creditmantri.com'
               )
recipients2 <- c(MailConfig$Marketing$all,
                 MailConfig$Product,
                 MailConfig$Assitted_channel$cis,
                 MailConfig$Finance)
cc_recipients = MailConfig$Datascience
myMessage = paste0("Product Yield MIS 2 - ", DATE)


if (TEST) {
  recipients1 <- sender
  recipients2 <- sender
  cc_recipients <- sender
  myMessage = paste0("{TEST} Product Yield MIS 2 - ", DATE)
}

mail_list <- list(recipients1,recipients2)

# <h3> CIS Visits Yield </h3>
#   <p> ${print(xtable(CIS_VISITS_FUNNEL, digits = 0), type = \'html\')} </p><br>


# message
msg = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <style>
    table {font-family:  Verdana, Geneva, sans-serif; font-size: 11px;
    width = 100%; border: 1px solid black; border-collapse: collapse;
    text-align: center; padding: 5px;}
    th {height = 12px;background-color: #4CAF50;color: white;}
    td {background-color: #FFF;}
    </style>
  </head>
  <body>
    <h3> ${myMessage} </h3><br>

    <h3> Login Metrics </h3>
    <p> ${print(xtable(LOGIN_METRICS, digits = 0), type = \'html\')} </p><br>
    <h3> Repeat Login Metrics </h3>
    <p> ${print(xtable(REPEAT_LOGIN_METRICS, digits = 0), type = \'html\')} </p><br>
    <h3> Red Repeat Saleable Login Metrics </h3>
    <p> ${print(xtable(RED_SALEABLE_LOGIN_METRICS, digits = 0), type = \'html\')} </p><br>
    <h3> Login Vintage - Unique Customers</h3>
    <p> ${print(xtable(UNIQUE_LOGIN_VINTAGE_METRICS, digits = 0), type = \'html\')} </p><br>

    <h3> CIS Yield </h3>
    <p> ${print(xtable(CIS_M0_FUNNEL, digits = 0), type = \'html\')} </p><br>
    
    
    <h3> CHR Yield - Red </h3>
    <p> ${print(xtable(CHR_FUNNEL_RED, digits = 0), type = \'html\')} </p><br>
    <h3> CHR Yield - Green </h3>
    <p> ${print(xtable(CHR_FUNNEL_GREEN, digits = 0), type = \'html\')} </p><br>
    <h3> CHR Visits Yield - Red </h3>
    <p> ${print(xtable(CHR_VISITS_RED_FUNNEL, digits = 0), type = \'html\')} </p><br>
    <h3> CHR Visits Yield - Green </h3>
    <p> ${print(xtable(CHR_VISITS_GREEN_FUNNEL, digits = 0), type = \'html\')} </p><br>
    
    <h3> BYS M0 Yield </h3>
    <p> ${print(xtable(BYS_M0_FUNNEL, digits = 0), type = \'html\')} </p><br>
    <h3> BYS Visits Yield </h3>
    <p> ${print(xtable(BYS_VISITS_FUNNEL, digits = 0), type = \'html\')} </p><br>
    
    

</body>
</html>'

loginfo("Product Yield MIS 2 - Email Body Formed")


retry({

lapply(mail_list, function(recipients){    
send.mail(from = sender,
          to = recipients,
          cc = cc_recipients,
          subject = myMessage,
          html = TRUE,
          inline = T,
          body = str_interp(msg),
          smtp = list(host.name = "email-smtp.us-east-1.amazonaws.com", port = 587,
                      user.name = "AKIAI7T5HYFCTUZMOV3Q",
                      passwd = "AtHel2jMbKGwbGlQjalkTZxEW144VM+LmgfLpNINg07E" , ssl = TRUE),
          #attach.files = c(output_filename),
          authenticate = TRUE,
          send = TRUE)
  })
})

loginfo("Product Yield MIS 2 - Email Sent")
logwarn("[DONE] Product Yield MIS 2 - Report Completed")
