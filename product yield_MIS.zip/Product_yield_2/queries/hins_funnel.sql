WITH base AS (
SELECT
    o.user_id,
    cp.customer_type,
    o.service_type,
    o.subtotal,
    o.updated_at,
    CASE 
        WHEN o.subtotal IN (647,895,1131,1164,1293,1379,1412,1422,1541,1670,2037,2263,2285,2489,2511,2737) THEN '1L'
        WHEN o.subtotal IN (1002,1250,1754,1804,2002,2004,2052,2205,2252,2453,3157,3405,3508,3756,3858,4106) THEN '3L'
        ELSE 'NULL'
    END as hins_band,
    o1.*
FROM 
    orders o
    LEFT JOIN LATERAL(
        SELECT
            o1.service_type as combo_product,
            o1.updated_at as chr_updated
        FROM 
            orders o1
        WHERE
            o1.user_id = o.user_id
            AND o1.updated_at >= o.updated_at - interval '10 mins'
            AND o1.updated_at < o.updated_at + interval '10 mins'
            AND o1.service_type IN ('CHR','CHRA','BYS')
    ) o1 ON TRUE
    LEFT JOIN 
        cm_cp_processed cp
        ON cp.user_id = o.user_id
        AND cp.customer_profile_id = (SELECT MAX(customer_profile_id) FROM cm_cp_processed WHERE user_id = o.user_id AND created_on < o.updated_at)
WHERE
    o.service_type = 'HINS'
    AND o.updated_at >= '{{START_DATE}}'
    AND o.updated_at < '{{END_DATE}}'
)

SELECT 
    hins_band as "HINS Band",
    customer_type as "Customer Type",
    COUNT(*) FILTER (WHERE combo_product ~* 'CHR')::integer as "HINS WITH CHR",
    COUNT(*) FILTER (WHERE combo_product ~* 'BYS')::integer as "HINS WITH BYS",
    COUNT(*) FILTER (WHERE combo_product is null)::integer as "HINS WITHOUT CHR/BYS"
FROM 
    base
GROUP BY 1,2
ORDER BY 2