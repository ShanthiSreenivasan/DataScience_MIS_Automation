WITH dat as (
  	SELECT
  	v.*,
    case 
      when month_diff(first_profile_date, '{{ START_DATE }}'::date) <= 1 then 'V0' 
      when month_diff(first_profile_date, '{{ START_DATE }}'::date) BETWEEN 2 AND 5 then 'V1'
      else 'V2'
		end as profile_vintage,
		CASE
			WHEN sub_oic not in ('System', 'PORTFOLIO') then 'Assisted'
			WHEN sub_oic = 'PORTFOLIO' then 'PA'
			else 'STP'
		end as attribution,
		latest.customer_type
	FROM
		product.vas_subscriptions v
        LEFT JOIN LATERAL (
				select customer_type
				from cm_cp_processed
				where user_id = v.user_id
				and created_on <= v.payment_date
				order by created_on desc
				limit 1) as latest on true
	LEFT JOIN LATERAL (
				select created_on as first_profile_date
				from cm_cp_processed
				where user_id = v.user_id
				order by created_on
				limit 1) as firsts on true
	WHERE
		v.service_type ~* '{{ SERVICE }}'
		and v.payment_date >= '{{ START_DATE }}'
		and v.payment_date < '{{ END_DATE }}'
	)
	
	select 
	case when grouping(profile_vintage) = 0 then profile_vintage else 'Total' end as "Profiled Month",
	case when grouping(attribution) = 0 then attribution else 'Total' end as "OIC",
	count(*) filter(where customer_type = 'Amber') as "{{ PERIOD }} Amber",
	count(*) filter(where customer_type = 'Red') as "{{ PERIOD }} Red",
	count(*) filter(where customer_type = 'Green') as "{{ PERIOD }} Green"
  from dat
  group by 
	rollup(profile_vintage,attribution)
	order by profile_vintage,attribution