WITH amber_logins AS (
    select distinct on (usl.user_id)
        usl.user_id,
        usl.created_at as login_date
    from 
        utm_source_log usl
        INNER JOIN 
            cm_cp_processed cp
            on cp.user_id = usl.user_id
    where
        cp.customer_profile_id = (
            select max(customer_profile_id) 
            from cm_cp_processed 
            where user_id = cp.user_id and created_on < usl.created_at
        )
        and usl.created_at >= '{{ START_DATE }}'
        and usl.created_at < '{{ END_DATE}}'
        and cp.p_customer_type = 3
)
SELECT
    count(*) as "Amber Unique Logins",
    count(*) filter (where oic_at_040 = 'System') as "BYS Page Visits - 040",
    (1 - round(
        count(*) filter (where oic_at_040 = 'System') / 
        count(*)::numeric, 3
    )) * 100 || ' %' as "BYS Page Visits Dropoff %",
    count(*) filter (where oic_at_050 = 'System') as "Payment Page - 050",
    (1 - round(
        count(*) filter (where oic_at_050 = 'System') / 
        count(*) filter (where oic_at_040 = 'System')::numeric, 3
    )) * 100 || ' %' as "Payment Page Dropoff %",
    count(*) filter (where oic_at_070 = 'System') as "BYS Paid - 070",
    (1- round(
        count(*) filter (where oic_at_070 = 'System') / 
        count(*) filter (where oic_at_050 = 'System')::numeric, 3
    )) * 100 || ' %' as "BYS Paid Dropoff %"
FROM 
    amber_logins al
    LEFT JOIN LATERAL (
        SELECT 
            min(log_updated_at) filter (where product_status ~*  '^bys.*000') pass_000_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*000'))[1] as oic_at_000,        
            min(log_updated_at) filter (where product_status ~*  '^bys.*040') pass_040_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*040'))[1] as oic_at_040,  
            min(log_updated_at) filter (where product_status ~*  '^bys.*050') pass_050_date,        
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*050'))[1] as oic_at_050,
            min(log_updated_at) filter (where product_status ~*  '^bys.*070') pass_070_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*070'))[1] as oic_at_070
        FROM
            consolidated_lead_logs
        WHERE
            user_id = al.user_id 
            and log_updated_at >= al.login_date
    ) cll ON TRUE