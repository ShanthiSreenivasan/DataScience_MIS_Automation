WITH amber_profiles AS (
    select
        cp.user_id,
        cp.created_on as profile_date
    from 
        cm_cp_processed cp
    where
        cp.customer_profile_id = (
            select min(customer_profile_id) 
            from cm_cp_processed 
            where user_id = cp.user_id
        )
        and cp.created_on >= '{{ START_DATE }}'
        and cp.created_on < '{{ END_DATE }}'
        and cp.p_customer_type = 3
)
SELECT
    count(*) as "Amber Profiles",
    count(*) filter (where oic_at_040 = 'System') as "Amber Page Visits - 040",
    (1 - round(
        count(*) filter (where oic_at_040 = 'System') / 
        count(*)::numeric, 3
    )) * 100 || ' %' as "BYS Page Visits Dropoff %",
    count(*) filter (where oic_at_050 = 'System') as "Payment Page - 050",
    (1 - round(
        count(*) filter (where oic_at_050 = 'System') / 
        count(*) filter (where oic_at_040 = 'System')::numeric, 3
    )) * 100 || ' %' as "Payment Page Dropoff %",
    count(*) filter (where oic_at_070 = 'System') as "BYS Paid - 070",
    (1- round(
        count(*) filter (where oic_at_070 = 'System') / 
        count(*) filter (where oic_at_050 = 'System')::numeric, 3
    )) * 100 || ' %' as "BYS Paid Dropoff %"
FROM 
    amber_profiles ap
    LEFT JOIN LATERAL (
        SELECT 
            min(log_updated_at) filter (where product_status ~*  '^bys.*000') pass_000_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*000'))[1] as oic_at_000,        
            min(log_updated_at) filter (where product_status ~*  '^bys.*040') pass_040_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*040'))[1] as oic_at_040,  
            min(log_updated_at) filter (where product_status ~*  '^bys.*050') pass_050_date,        
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*050'))[1] as oic_at_050,
            min(log_updated_at) filter (where product_status ~*  '^bys.*070') pass_070_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^bys.*070'))[1] as oic_at_070
        FROM
            consolidated_lead_logs
        WHERE
            user_id = ap.user_id 
            and log_updated_at >= ap.profile_date
    ) cll ON TRUE