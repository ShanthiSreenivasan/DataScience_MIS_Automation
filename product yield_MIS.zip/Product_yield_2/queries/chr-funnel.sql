select
    cp.user_id,
    cp.created_on profiled_date,
    cp.customer_type,
    cp.is_saleable,
    cll.*
from 
    cm_cp_processed cp
    left join lateral (
        select 
            min(log_updated_at) filter (where product_status ~* '^chr.*000') undecided_date,
            bool_or(source = 'CRM' and lead_log_type = 'Status Change' and crm_status_text !~* '.*(nc|rnr|ring).*') 
                filter (where product_status ~* '^chr.*000') undecided_if_assisted,
            min(log_updated_at) filter (where product_status ~* '^chr.*040') pp_date,
            bool_or(source = 'CRM' and lead_log_type = 'Status Change' and crm_status_text !~* '.*(nc|rnr|ring).*') 
                filter (where product_status ~* '^chr.*040') pp_if_assisted,
            min(log_updated_at) filter (where product_status ~* '^chr.*050') pg_date,
            bool_or(source = 'CRM' and lead_log_type = 'Status Change' and crm_status_text !~* '.*(nc|rnr|ring).*') 
                filter (where product_status ~* '^chr.*050') pg_if_assisted,
            min(log_updated_at) filter (where product_status ~* '^chr.*070') paid_date,
            bool_or(source = 'CRM' and lead_log_type = 'Status Change' and crm_status_text !~* '.*(nc|rnr|ring).*') 
                filter (where product_status ~* '^chr.*070') paid_if_assisted
        from consolidated_cis_lead_logs 
        where user_id = cp.user_id
    ) cll on true
where
    cp.customer_profile_id = (SELECT min(customer_profile_id) FROM cm_cp_processed WHERE user_id = cp.user_id)
    and cp.customer_type in ('Red', 'Green')
    and cp.created_on >= '{{ START_DATE }}' 
    and cp.created_on < '{{ END_DATE }}'