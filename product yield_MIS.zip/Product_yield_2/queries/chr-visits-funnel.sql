select
	cc.*,
	cll.*,
	cp1.customer_type
from
	(
		select distinct on (user_id, date(log_updated_at))
			user_id, log_updated_at chr_visit_date
		from consolidated_cis_lead_logs
		where
			product_status ~* 'chr.*040'
			and log_updated_at >= '{{ START_DATE }}' 
			and log_updated_at < '{{ END_DATE }}'
		order by user_id
	) cc
	left join lateral (
		select 
			bool_or(product_status ~* 'chr.*040')::integer chr_visited,
			bool_or(product_status ~* 'chr.*050')::integer pay_now,
			bool_or(product_status ~* 'chr.*070')::integer made_payment
		from 
			consolidated_cis_lead_logs
		where
			user_id = cc.user_id
			and log_updated_at >= chr_visit_date
			and log_updated_at < '{{ END_DATE }}'
	) cll on true
	left join lateral (
	  select
	    customer_type
    from cm_cp_processed cp
    where user_id = cc.user_id
    and customer_profile_id = (SELECT max(customer_profile_id) FROM cm_cp_processed WHERE user_id = cp.user_id)
	) cp1 on true
	