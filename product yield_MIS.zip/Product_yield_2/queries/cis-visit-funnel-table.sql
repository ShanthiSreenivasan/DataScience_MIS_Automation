INSERT INTO test.cis_visit_funnel (
WITH logins AS (
    SELECT 
        DISTINCT ON (usl.user_id)
        usl.user_id,
        usl.utm_source,
        usl.created_at as login_date
    FROM 
        usl_currentmonth usl
    WHERE
        usl.created_at >= '{{START_DATE}}'
        AND usl.created_at < '{{END_DATE}}'
    ORDER BY user_id, usl.created_at
), --Get only Red users
 repeat_logins AS ( 
    SELECT
        l.*,
        cp.customer_profile_id,
        cp.customer_type
    FROM 
        logins l
        inner JOIN 
            cm_cp_processed cp
            ON cp.user_id = l.user_id
            AND cp.customer_profile_id = (SELECT customer_profile_id FROM cm_cp_processed WHERE user_id = l.user_id and created_on < l.login_date order by customer_profile_id desc limit 1)
    WHERE    
        exists (SELECT 1 FROM cm_cp_processed WHERE user_id = l.user_id and is_active = 0 order by customer_profile_id desc limit 1)
        and cp.customer_type = 'Red'
), --Red Repeat Saleable Users
red_logins AS (
SELECT
    cp.*,
    cpa.*
FROM 
    repeat_logins cp
   left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1 
            LEFT JOIN LATERAL (
                SELECT
                    case when las.is_customer = 1 and las.enable_diy = 1 then 1 else 0 end as is_ldb
                FROM
                    master_tables.lender_account_status las 
                WHERE 
                    las.product_family_id = cpa.product_family_id 
                    AND las.lender_id = cpa.lender_id 
                    AND las.account_status_id = cpa.account_status_master_id
                LIMIT 1
            ) ldb_stat on true
        where
            customer_profile_id = cp.customer_profile_id
    ) cpa on true

)

SELECT
    *
FROM 
    red_logins
)