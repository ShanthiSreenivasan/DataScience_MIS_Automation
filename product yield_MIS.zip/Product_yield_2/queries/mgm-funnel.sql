SELECT 
	ur.user_id,
    ur.created_at registration_date,
    cp.created_on profiled_on,
    cp.customer_type
FROM
    user_referrals ur
    LEFT JOIN
        cm_cp_processed cp
        on cp.user_id = ur.user_id
        and cp.customer_profile_id = (SELECT min(customer_profile_id) FROM cm_cp_processed WHERE user_id = cp.user_id)
WHERE 
    ur.created_at >= '{{ START_DATE }}' 
    and ur.created_at < '{{ END_DATE }}'