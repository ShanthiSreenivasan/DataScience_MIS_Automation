with dat as (
	SELECT
		v.*,
		CASE
			WHEN sub_oic not in ('System', 'PORTFOLIO') then 'Assisted'
			WHEN sub_oic = 'PORTFOLIO' then 'PA'
			else 'STP'
		end as attribution
	FROM
		product.vas_subscriptions v
	WHERE
		v.service_type ~* '{{ SERVICE }}'
		and v.payment_date >= '{{ START_DATE }}'
		and v.payment_date < '{{ END_DATE }}'
)
select 
	case when grouping(attribution) = 0 then attribution else 'Total' end as "OIC",
	count(*) as "{{ PERIOD }}"
from 	
	dat
group by 
	rollup(attribution)