select 
cp.user_id ,
case when cp.p_customer_type =1 then 'Green'
    when cp.p_customer_type =2 then 'Red'
    when cp.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type ,
cp.created_on ,
saleable.*,
uai.usr_level_whatsapp_consent 
from 
cm_cp_processed cp 
left join users_additional_info uai 
on uai.user_id=cp.user_id 
left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1
				where
			customer_profile_id = cp.customer_profile_id	) saleable on true
where cp.created_on >='{{START_DATE}}'
and  cp.created_on <'{{END_DATE}}'
and cp.customer_profile_id = (SELECT customer_profile_id FROM cm_cp_processed WHERE user_id = cp.user_id ORDER BY created_on LIMIT 1)
and cp.p_customer_type is not null