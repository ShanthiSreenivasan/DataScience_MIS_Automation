-- STP
SELECT
    COUNT(distinct user_id) FILTER ( WHERE flag_1 = 1 OR flag_2 = 1) as "CHR Renewal Logins",
    COUNT(distinct user_id) FILTER ( WHERE pass_040 = 1 AND (flag_1 = 1 OR flag_2 = 1)) as "CHR Renewal 040",
    COUNT(distinct user_id) FILTER ( WHERE pass_050 = 1 AND (flag_1 = 1 OR flag_2 = 1)) as "CHR Renewal 050",
    COUNT(distinct user_id) FILTER ( WHERE has_sub = 1 and flag_1 = 1 ) as "CHR Renewal"
FROM 
    usl_currentmonth usl
    LEFT JOIN LATERAL(
        SELECT 
            bool_or(product_status ~* 'CHR(.*?)040')::integer as pass_040,
            bool_or(product_status ~* 'CHR(.*?)050')::integer as pass_050,
            bool_or(product_status ~* 'CHR(.*?)(070|100)')::integer as pass_100
        FROM 
            consolidated_lead_logs cll
        WHERE
            cll.user_id = usl.user_id
            AND cll.log_updated_at >= usl.created_at 
            AND cll.log_updated_at < usl.created_at + interval '15 mins'
    ) chr ON TRUE
    LEFT JOIN LATERAL(
        SELECT
            1 as has_sub
        FROM 
            product.vas_subscriptions vs
        WHERE 
            vs.user_id = usl.user_id 
            AND vs.payment_date >= '{{ START_DATE }}'
            AND vs.payment_date < '{{ END_DATE }}'
            AND vs.utm_source_text ~* 'CHR_renewal_(S|E)'
    ) ch ON TRUE
    LEFT JOIN LATERAL (
        SELECT 
            1 as flag_1
        FROM 
            product.vas_subscriptions vas
        WHERE 
            user_id = usl.user_id
            AND service_type ~* 'CHR'
            AND order_total > 0
            AND user_service_order_id < (SELECT user_service_order_id FROM product.vas_subscriptions WHERE user_id = usl.user_id AND service_type ~* 'CHR'  ORDER BY user_service_order_id DESC LIMIT 1)
        LIMIT 1
    ) chr_ren ON TRUE
    LEFT JOIN LATERAL (
        SELECT 
            1 as flag_2
        FROM 
            user_service_orders uso
        WHERE
            uso.user_id = usl.user_id
            AND uso.id = (SELECT id FROM user_service_orders WHERE user_id = uso.user_id AND service_type IN ('CHR','CHRA') ORDER BY id DESC LIMIT 1)
            AND uso.service_type IN ('CHR','CHRA')
            AND uso.service_expiry_date < '{{ NXT_MONTH_END_DATE }}'
    ) chr_ren1 ON TRUE

WHERE
    usl.utm_source ~* 'CHR_renewal_(S|E)'
    AND usl.created_at >= '{{ START_DATE }}'
    AND usl.created_at < '{{ END_DATE }}'