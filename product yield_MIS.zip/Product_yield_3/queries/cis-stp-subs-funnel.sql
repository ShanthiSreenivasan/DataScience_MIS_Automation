select
	get_latest_utm(user_id, created_on) as utm,
	count(*) as profiles,
    count(*) filter (where cpa.nsaleable > 0) as saleable_profiles,
    count(*) filter (where ord.has_subbed = 1) as subbed_users,
    sum(accounts) as accounts
from
	cm_cp_processed cp
	left join lateral (
        select 
            (count(*) > 0)::integer as has_subbed,
            sum(accounts) as accounts
        from
            cis.cis_subscriptions
        where
            user_id = cp.user_id
            and sub_oic = 'System'
            and payment_date >= '{{START_DATE}}'
            and payment_date < '{{END_DATE}}'
    ) ord on true
    left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1
				where
			customer_profile_id = cp.customer_profile_id
) cpa on true
where
	cp.customer_profile_id = (select min(customer_profile_id) from cm_cp_processed where user_id = cp.user_id)
	and cp.p_customer_type = 2
	and cp.created_on >= '{{START_DATE}}'
	and cp.created_on < '{{END_DATE}}'
group by 
	1