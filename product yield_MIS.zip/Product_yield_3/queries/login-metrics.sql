    select
        usl.user_id,
        usl.created_at as login_date,
        case when usl.utm_source_text ~* 'android' then 1 else 0 end as is_android_login,
        case
            when has_profile = 1 then coalesce(prof.customer_type, 'NA')
            else 'Not Profiled'
        end as customer_type,
        case when u.created_on < '{{MONTH_START_DATE}}' then 1 else 0 end as has_repeat_login,
        case
        when utm.utm_source_text ~* '^CRM-(?=.*[0-9].*)(?=.*[A-Z].*)[A-Z0-9]+$' 
          then 'Assisted'
        when utm.utm_source_text ~* '^(?=.*[0-9].*_)(?=.*[A-Z].*_)[A-Z0-9]+_androidapp' 
          then 'Assisted'
        when utm.utm_source_text ~* 'androidapp'
          then 'Android App'
        when utm.utm_source_text ~* '(home|getstarted|amp|pre-login-eligibility-btn)' 
          then 'System'
        when utm.utm_source_text ~* '(^email|^sms|sms$|pa)' and utm.utm_source_text !~* 'monitoring' 
          then 'PORTFOLIO'
        when utm.utm_source_text ~* '(ces-referral|arsce|cem-referral)'
          then 'Customer Engagement'
        when utm.utm_source_text ~* '(^email|^sms|sms$)' and utm.utm_source_text ~* 'monitoring'
          then 'E-mail/SMS Monitoring'
        when utm.utm_source_text ~* '(adcanopus|aqugen|bing|fb|geoadsmedia|google_search|google_display|techslash|text91|vfnativered|valuedirect_ca_1|yulore_ca|adsplay|mymoneymantra|pointific_new|profiliadnew|svgcolumbus|valueleafnative|yoadsmedia|intellectads)'
          then 'Marketing(Networks)'
        else 'Other'
        end as channel,
        cpa.*,
        (SELECT created_on FROM cm_cp_processed WHERE user_id = usl.user_id ORDER BY created_on LIMIT 1) as first_profile_date
    from 
        usl_currentmonth usl
        left join lateral(
			      select created_on
			      from users
            where  user_id = usl.user_id
            )u on true
        left join lateral (
          select utm_source_text
          from usl_currentmonth 
          where user_id = usl.user_id 
          and created_at >= '{{START_DATE}}' 
          and created_at < '{{END_DATE}}' 
          order by created_at
          limit 1 
        ) utm on true
        LEFT JOIN LATERAL (
            select
                customer_type,
                1 as has_profile,
                customer_profile_id
            from 
                cm_cp_processed 
            where
                user_id = usl.user_id
            order by 
                created_on desc
            limit 1
        ) prof ON TRUE
        left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1 
            LEFT JOIN LATERAL (
                SELECT
                    case when las.is_customer = 1 and las.enable_diy = 1 then 1 else 0 end as is_ldb
                FROM
                    master_tables.lender_account_status las 
                WHERE 
                    las.product_family_id = cpa.product_family_id 
                    AND las.lender_id = cpa.lender_id 
                    AND las.account_status_id = cpa.account_status_master_id
                LIMIT 1
            ) ldb_stat on true
        where
            customer_profile_id = prof.customer_profile_id
    ) cpa on true
    where  
        usl.created_at >= '{{START_DATE}}'
        and usl.created_at < '{{END_DATE}}'