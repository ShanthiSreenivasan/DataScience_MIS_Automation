loginfo("Product Yield MIS - 5-bys-funnel.R Started")


#*******************************************************************************
#*******************************************************************************
## 1. BYS New Funnel =======
#*******************************************************************************
#*******************************************************************************

#' Funnel for Amber customers who were newly profiled this month. 
#' Looks at performance through 040, 050 and 070.
# 
start_time <- Sys.time()
query = 'bys-new-funnel.sql - DTD'

bys_funnel_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-new-funnel.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'Daily', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'bys-new-funnel.sql - MTD'

bys_funnel_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-new-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'MTD', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_M0_FUNNEL <- full_join(bys_funnel_dtd, bys_funnel_mtd)


#*******************************************************************************
#*******************************************************************************
## 2. BYS Visits Funnel =======
#*******************************************************************************
#*******************************************************************************

#' Funnel for customers who have visited the BYS 040 / prepayment page in this 
#' day/month
start_time <- Sys.time()
query = 'bys-visits-funnel.sql - DTD'

bys_visits_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-visits-funnel.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'Daily', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'bys-visits-funnel.sql - MTD'

bys_visits_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/bys-visits-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  gather_('Metric', 'MTD', names(.))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_VISITS_FUNNEL <- full_join(bys_visits_dtd, bys_visits_mtd)


loginfo("Product Yield MIS - 5-bys-funnel.R BYS Visits completed")

#*******************************************************************************
#*******************************************************************************
## 3. BYS Actuals =======
#*******************************************************************************
#*******************************************************************************
start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - DTD'

bys_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - MTD'

bys_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_SUBSCRIPTIONS <- full_join(bys_dtd, bys_mtd) %>% 
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - DTD'

bys_dtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - MTD'

bys_mtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 

BYS_SUBSCRIPTIONS_VINTAGE <- full_join(bys_dtd_vin, bys_mtd_vin)  %>% 
  arrange(ifelse(`Profiled Month` == 'Total', 'ZZZ', `Profiled Month`))%>%  
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

loginfo("Product Yield MIS - 5-bys-funnel.R BYS Actuals Completed")
