#' Similar to the CIS Funnel, the Referrals Funnel looks at the flow of a Green 
#' profiled customer showing interest in one of the LenderOffer products. 
#' 
#' The funnel considers movement upto the 07 stage and excludes customers who were
#' closed by an OIC with the stamping 110.

loginfo("Product Yield MIS - 3-referrals-funnel.R Started")

#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M0 Funnel =======
#*******************************************************************************


loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0+ Query Started")

AMBER_M0PLUS_STP_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = 'Amber')
))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0+ Query Completed")
#*******************************************************************************
## 1.1 Green M0 Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0+ Query Started")

GREEN_M0PLUS_STP_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = 'Green')
))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0+ Query Completed")
#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M0 Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0 Query Started")

AMBER_M0_STP_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = 'Amber')
))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0 Query Completed")
#*******************************************************************************
## 1.1 Green M0 Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0 Query Started")

GREEN_M0_STP_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = 'Green')
))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0 Query Completed")