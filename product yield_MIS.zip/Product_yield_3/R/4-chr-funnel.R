loginfo("Product Yield MIS - 4-chr-funnel.R Started")



### CHR Renewals

start_time <- Sys.time()
query = 'chr-renewal-visits.sql'

# CHR_RENEWALS <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/chr-renewal-visits-new.sql'),
#   list(
#     MONTH_START = MONTH_START, 
#     DTD_DATE = DATE,
#     END_DATE = DATE + days(1),
#     NXT_MONTH_START = NXT_MONTH_START,
#     NXT_DTD_START = NXT_DTD_START,
#     NXT_END_START = NXT_DTD_START + days(1))
# ))

PERIODS <- list(
  "DTD" = c(DATE, DATE + days(1)),
  "MTD" = c(MONTH_START, DATE + days(1))
)

CHR_RENEWALS_ELIGIBLE <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-renewal-eligible.sql'),
  list(
    NXT_MONTH_START = NXT_MONTH_START,
    NXT_DTD_START = NXT_DTD_START,
    NXT_MONTH_END = NXT_DTD_START + days(1))
))

loginfo("Product Yield MIS - 4-chr-funnel.R - CHR_RENEWALS_LOGINS - completed")

CHR_RENEWALS_STP <- lapply(names(PERIODS), function(period){
  
  funnel <- data.table(read_sql2(
    get_conn(),
    file.path(MIS_PATH, 'queries/chr-renewal-stp-logins.sql'),
    list(
      START_DATE = PERIODS[[period]][1], 
      END_DATE = PERIODS[[period]][2],
      NXT_MONTH_END_DATE = ymd(Sys.Date() + days(31)))
  ))
  
  gather_(funnel,'Metrics', period, gather_cols = names(funnel))
  
}) %>% 
  reduce(full_join)

loginfo("Product Yield MIS - 4-chr-funnel.R - CHR_RENEWALS_STP - completed")

CHR_RENEWALS_PA <- lapply(names(PERIODS), function(period){
  
  funnel <- data.table(read_sql2(
    get_conn(),
    file.path(MIS_PATH, 'queries/chr-renewal-pa-logins.sql'),
    list(
      START_DATE = PERIODS[[period]][1], 
      END_DATE = PERIODS[[period]][2],
      NXT_MONTH_END_DATE = ymd(Sys.Date() + days(31)))
  ))
  
  gather_(funnel,'Metrics', period, gather_cols = names(funnel))
  
}) %>% 
  reduce(full_join)

loginfo("Product Yield MIS - 4-chr-funnel.R - CHR_RENEWALS_PA - completed")
