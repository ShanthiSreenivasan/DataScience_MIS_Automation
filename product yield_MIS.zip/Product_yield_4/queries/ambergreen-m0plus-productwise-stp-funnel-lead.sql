WITH logins AS (
    select distinct on (usl.user_id, to_char(usl.created_at, 'YYYY-MM'))
        usl.user_id,
        usl.created_at as login_date
    from 
        utm_source_log usl
        INNER JOIN 
            cm_cp_processed cp
            on cp.user_id = usl.user_id
            AND cp.customer_profile_id = (SELECT customer_profile_id FROM cm_cp_processed WHERE user_id = usl.user_id and is_active = 1 order by customer_profile_id desc limit 1)
    where
        usl.created_at >= '{{ START_DATE }}'
        and usl.created_at < '{{ END_DATE}}'
        and cp.p_customer_type = '{{ customer_type }}'
        AND exists (SELECT 1 FROM cm_cp_processed WHERE user_id = usl.user_id and is_active = 0 order by customer_profile_id desc limit 1)
        --and (select to_char(min(created_on), 'YYYY-MM') from cm_cp_processed where user_id = cp.user_id) < to_char(usl.created_at, 'YYYY-MM')
    --ORDER BY 
      --  user_id, to_char(usl.created_at, 'YYYY-MM'), usl.created_at
    --Limit 100000
)
SELECT
    CASE WHEN grouping(product) = 0 then product else 'Total' end as "Product",
    count(*) as "{{customer_type}} Profiles",
    sum(oic_at_021)  as "Stage 021",
    (1 - round(
        sum(oic_at_021) /
        nullif(count(*), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 021 Dropoff %",
    sum(oic_at_03) as "Stage 03",
    (1 - round(
        sum(oic_at_03)/
        nullif(sum(oic_at_021), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 03 Dropoff %",
    sum(oic_at_88) as "Stage 88",
    (round(
        sum(oic_at_88)/
        nullif(sum(oic_at_03), 0)::numeric, 3
    )) * 100 || ' %' as "Stage88 % Stage03",
    sum(oic_at_07 )as "Stage 07",
    (1- round(
        sum(oic_at_07)/
        nullif(sum(oic_at_03) , 0)::numeric, 3
    )) * 100 || ' %' as "Stage 07 Dropoff %"
FROM 
    logins l
    LEFT JOIN LATERAL (
        SELECT
            CASE WHEN grouping(split_part(product_status, '-', 1)) = 0 then split_part(product_status, '-', 1) else 'Total' end as product,
            sum( case when product_status ~*  '021$'and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_021,
            sum( case when product_status ~*  '03$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_03,
            sum( case when product_status ~*  '88$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_88,
            sum( case when product_status ~*  '07$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_07
        FROM
            consolidated_lead_logs
        WHERE
            user_id = l.user_id 
            and log_updated_at >= l.login_date
            and to_char(log_updated_at, 'YYYY-MM') = to_char(l.login_date, 'YYYY-MM') 
            AND lead_type = 'LenderOffer'
        GROUP BY
            ROLLUP(split_part(product_status, '-', 1))
    ) cll ON TRUE
WHERE
    cll.product is not null
GROUP BY 
    product
--ORDER BY 1