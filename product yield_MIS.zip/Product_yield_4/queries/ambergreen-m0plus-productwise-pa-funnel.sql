WITH logins AS (
    select distinct on (usl.user_id, to_char(usl.created_at, 'YYYY-MM'))
        usl.user_id,
        usl.created_at as login_date
    from 
       -- utm_source_log usl
       usl_currentmonth usl
        INNER JOIN 
            cm_cp_processed cp
            on cp.user_id = usl.user_id
            AND cp.customer_profile_id = (SELECT customer_profile_id FROM cm_cp_processed WHERE user_id = usl.user_id and is_active = 1 order by customer_profile_id desc limit 1)
    where
        usl.created_at >= '{{ START_DATE }}'
        and usl.created_at < '{{ END_DATE}}'
        and cp.p_customer_type = '{{ customer_type }}'
        and usl.utm_source_text~*'(email|sms|pa|PA)'
        and usl.utm_source_text!~*'monitoring'
        AND exists (SELECT 1 FROM cm_cp_processed WHERE user_id = usl.user_id and is_active = 0 order by customer_profile_id desc limit 1)
        --and (select to_char(min(created_on), 'YYYY-MM') from cm_cp_processed where user_id = cp.user_id) < to_char(usl.created_at, 'YYYY-MM')
   -- ORDER BY 
     --   user_id, to_char(usl.created_at, 'YYYY-MM'), usl.created_at
     --limit 100000
)
SELECT
    CASE WHEN grouping(product) = 0 then product else 'Total' end as "Product",
    count(*) as "{{ customer_type }} Unique Logins",
    count(*) filter (where oic_at_021 ~*'021') as "Stage 021",
    (1 - round(
        count(*) filter (where oic_at_021 ~*'021') / 
        nullif(count(*), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 021 Dropoff %",
    count(*) filter (where oic_at_03 ~*'03') as "Stage 03",
    (1 - round(
        count(*) filter (where oic_at_03 ~*'03') / 
        nullif(count(*) filter (where oic_at_021 ~*'021'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 03 Dropoff %",
    count(*) filter (where oic_at_03 ~*'03' and oic_at_88 ~*'88') as "Stage 88",
    (round(
        count(*) filter (where oic_at_03 ~*'03' and oic_at_88 ~*'88') / 
        nullif(count(*) filter (where oic_at_03 ~*'03'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage88 % Stage03",
    count(*) filter (where oic_at_07 ~*'07') as "Stage 07",
    (1- round(
        count(*) filter (where oic_at_07 ~*'07') / 
        nullif(count(*) filter (where oic_at_03 ~*'03'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 07 Dropoff %"
FROM 
    logins l
    LEFT JOIN LATERAL (
        SELECT 
            CASE WHEN grouping(split_part(product_status, '-', 1)) = 0 then split_part(product_status, '-', 1) else 'Total' end as product,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '021$'))[1] as oic_at_021,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '03$'))[1] as oic_at_03,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '88$'))[1] as oic_at_88,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '07$'))[1] as oic_at_07
        FROM
            consolidated_lead_logs
        WHERE
            user_id = l.user_id 
            and log_updated_at >= l.login_date
            and to_char(log_updated_at, 'YYYY-MM') = to_char(l.login_date, 'YYYY-MM') 
            AND lead_type = 'LenderOffer'
        GROUP BY
            ROLLUP(split_part(product_status, '-', 1))
    ) cll ON TRUE
   /* LEFT JOIN LATERAL(
    select 
        usl.user_id,
        usl.utm_source_text,
        usl.utm_content
    from 
        utm_source_log usl
    where
        usl.user_id=l.user_id
        and usl.created_at >= '{{ START_DATE }}'
        and usl.created_at < '{{ END_DATE}}'
       -- order by usl.created_at
      --  limit 1
    )usl1 on true*/
WHERE
    cll.product is not null
   -- AND usl1.utm_source_text~*'(email|sms|pa|PA)'
GROUP BY 
    product
--ORDER BY 1