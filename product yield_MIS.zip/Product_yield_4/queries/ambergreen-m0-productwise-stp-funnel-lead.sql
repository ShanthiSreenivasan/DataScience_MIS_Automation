SELECT
    CASE WHEN grouping(product) = 0 then product else 'Total' end as "Product",
    count(*) as "{{customer_type}} Profiles",
    sum(oic_at_021)  as "Stage 021",
    (1 - round(
        sum(oic_at_021) /
        nullif(count(*), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 021 Dropoff %",
    sum(oic_at_03) as "Stage 03",
    (1 - round(
        sum(oic_at_03)/
        nullif(sum(oic_at_021), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 03 Dropoff %",
    sum(oic_at_88) as "Stage 88",
    (round(
        sum(oic_at_88)/
        nullif(sum(oic_at_03), 0)::numeric, 3
    )) * 100 || ' %' as "Stage88 % Stage03",
    sum(oic_at_07 )as "Stage 07",
    (1- round(
        sum(oic_at_07)/
        nullif(sum(oic_at_03) , 0)::numeric, 3
    )) * 100 || ' %' as "Stage 07 Dropoff %"
FROM
    (select cp1.*, case when cp1.p_customer_type =1 then 'Green'
    when cp1.p_customer_type =2 then 'Red'
    when cp1.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type
    from cm_cp_processed cp1)cp
    LEFT JOIN LATERAL (
        SELECT
            CASE WHEN grouping(split_part(product_status, '-', 1)) = 0 then split_part(product_status, '-', 1) else 'Total' end as product,
            sum( case when product_status ~*  '021$'and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_021,
            sum( case when product_status ~*  '03$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_03,
            sum( case when product_status ~*  '88$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_88,
            sum( case when product_status ~*  '07$' and updated_by_oic= 'System' and lead_log_type = 'Product Status Change' then 1 else  0 end ) as oic_at_07
        FROM
            consolidated_lead_logs
        WHERE
            user_id = cp.user_id
            and log_updated_at >= cp.created_on
            and to_char(log_updated_at, 'YYYY-MM') = to_char(cp.created_on, 'YYYY-MM')
            AND lead_type = 'LenderOffer'
        GROUP BY
            ROLLUP(split_part(product_status, '-', 1))
    ) cll ON TRUE
WHERE
    cp.customer_profile_id = (select min(customer_profile_id) from cm_cp_processed where user_id = cp.user_id)
    and cp.created_on >= '{{START_DATE}}'
    and cp.created_on < '{{END_DATE}}'
    and p_customer_type  = '{{customer_type}}'
    AND cll.product is not null
GROUP BY
    product