SELECT
    CASE WHEN grouping(product) = 0 then product else 'Total' end as "Product",
    count(*) as "{{ customer_type }} Profiles",
    count(*) filter (where oic_at_021~*'021') as "Stage 021",
    (1 - round(
        count(*) filter (where oic_at_021 ~*'021') / 
        nullif(count(*), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 021 Dropoff %",
    count(*) filter (where oic_at_03 ~*'03') as "Stage 03",
    (1 - round(
        count(*) filter (where oic_at_03 ~*'03') / 
        nullif(count(*) filter (where oic_at_021 ~*'021'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 03 Dropoff %",
    count(*) filter (where oic_at_03 ~*'03' and oic_at_88 ~*'88') as "Stage 88",
    (round(
        count(*) filter (where oic_at_03 ~*'03' and oic_at_88 ~*'88') / 
        nullif(count(*) filter (where oic_at_03 ~*'03'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage88 % Stage03",
    count(*) filter (where oic_at_07 ~*'07') as "Stage 07",
    (1- round(
        count(*) filter (where oic_at_07 ~*'07') / 
        nullif(count(*) filter (where oic_at_03 ~*'03'), 0)::numeric, 3
    )) * 100 || ' %' as "Stage 07 Dropoff %"
FROM 
    cm_cp_processed cp
    LEFT JOIN LATERAL (
        SELECT 
            CASE WHEN grouping(split_part(product_status, '-', 1)) = 0 then split_part(product_status, '-', 1) else 'Total' end as product,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '021$'))[1] as oic_at_021,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '03$'))[1] as oic_at_03,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '88$'))[1] as oic_at_88,
            (array_agg(product_status order by log_updated_at) filter (where product_status ~*  '07$'))[1] as oic_at_07
        FROM
            consolidated_lead_logs
        WHERE
            user_id = cp.user_id 
            and log_updated_at >= cp.created_on
            and to_char(log_updated_at, 'YYYY-MM') = to_char(cp.created_on, 'YYYY-MM') 
            AND lead_type = 'LenderOffer'
        GROUP BY
            ROLLUP(split_part(product_status, '-', 1))
    ) cll ON TRUE
    LEFT JOIN LATERAL(
    select 
        usl.user_id,
        usl.utm_source_text,
        usl.utm_content
    from 
        utm_source_log usl
        
    where
        usl.user_id=cp.user_id
        and usl.created_at >= '{{ START_DATE }}'
        and usl.created_at < '{{ END_DATE}}'
        --order by usl.created_at
        --limit 1
    )usl1 on true
WHERE
    cp.customer_profile_id = (select min(customer_profile_id) from cm_cp_processed where user_id = cp.user_id)
    and cp.created_on >= '{{ START_DATE }}'
    and cp.created_on < '{{ END_DATE }}'
    and cp.p_customer_type = '{{ customer_type }}'
    AND cll.product is not null
    AND usl1.utm_source_text~*'(email|sms|pa|PA)'
    and usl1.utm_source_text!~*'monitoring'
GROUP BY 
    product