#' Similar to the CIS Funnel, the Referrals Funnel looks at the flow of a Green 
#' profiled customer showing interest in one of the LenderOffer products. 
#' 
#' The funnel considers movement upto the 07 stage and excludes customers who were
#' closed by an OIC with the stamping 110.

loginfo("Product Yield MIS - 3-referrals-funnel.R Started")

# lead level

#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M2+ Funnel =======
#*******************************************************************************


loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M2+ Query Started")

# AMBER_M2PLUS_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

AMBER_M0PLUS_PA_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-pa-funnel.sql'),
  list(START_DATE = floor_date(MONTH_START,"months"), END_DATE = DATE + days(1), customer_type = '3')
))


loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M2+ Query Completed")
#*******************************************************************************
## 1.1 Green M2+ Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M2+ Query Started")

# GREEN_M2PLUS_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

GREEN_M0PLUS_PA_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-pa-funnel.sql'),
  list(START_DATE = floor_date(MONTH_START,"months"), END_DATE = DATE + days(1), customer_type = '1')
))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M2+ Query Completed")
#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M0,M1,M2 Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0,M1,M2 Query Started")

# AMBER_M0_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '3')
# ))
# 
# AMBER_M1_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '3')
# ))
# 
# AMBER_M2_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

AMBER_M0_PA_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '3')
))
# 
# AMBER_M1_PA_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-lead.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '3')
# ))
# 
# AMBER_M2_PA_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0,M1,M2 Query Completed")
#*******************************************************************************
## 1.1 Green M0,M1,M2 Funnel =======
#*******************************************************************************

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0,M1,M2 Query Started")

# GREEN_M0_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '1')
# ))
# 
# GREEN_M1_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '1')
# ))
# 
# GREEN_M2_STP_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

GREEN_M0_PA_FUNNEL <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '1')
))

# GREEN_M1_PA_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-lead.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '1')
# ))

# GREEN_M2_PA_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-lead.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0,M1,M2 Query Completed")


# user level

#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M2+ Funnel =======
#*******************************************************************************


# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M2+ Query Started")

# AMBER_M2PLUS_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

# AMBER_M2PLUS_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))


# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M2+ Query Completed")
#*******************************************************************************
## 1.1 Green M2+ Funnel =======
#*******************************************************************************

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M2+ Query Started")
# 
# GREEN_M2PLUS_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

# GREEN_M2PLUS_PA_FUNNEL <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0plus-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE = floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M2+ Query Completed")
#*******************************************************************************
#*******************************************************************************
## 1. M0 Funnels =======
#*******************************************************************************
#*******************************************************************************

#*******************************************************************************
## 1.1 Amber M0,M1,M2 Funnel =======
#*******************************************************************************

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0,M1,M2 Query Started")
# 
# AMBER_M0_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '3')
# ))
# 
# AMBER_M1_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '3')
# ))
# 
# AMBER_M2_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

# AMBER_M0_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '3')
# ))
# 
# AMBER_M1_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '3')
# ))
# 
# AMBER_M2_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '3')
# ))

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Amber M0,M1,M2 Query Completed")
#*******************************************************************************
## 1.1 Green M0,M1,M2 Funnel =======
#*******************************************************************************

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0,M1,M2 Query Started")
# 
# GREEN_M0_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '1')
# ))
# 
# GREEN_M1_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '1')
# ))
# 
# GREEN_M2_STP_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-stp-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

# GREEN_M0_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1), customer_type = '1')
# ))
# 
# GREEN_M1_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(MONTH_START-days(10),"months"), END_DATE=floor_date(MONTH_START,"months"), customer_type = '1')
# ))

# GREEN_M2_PA_FUNNEL_USER <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/ambergreen-m0-productwise-pa-funnel-user.sql'),
#   list(START_DATE = floor_date(floor_date(MONTH_START-days(10),"months")-days(10),"months"), END_DATE=floor_date(MONTH_START-days(10),"months"), customer_type = '1')
# ))

# loginfo("Product Yield MIS - 3-referrals-funnel.R Visits Green M0,M1,M2 Query Completed")