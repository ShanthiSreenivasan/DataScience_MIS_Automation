# 11-email-sms-monitoring
loginfo("Product Yield MIS - Email-sms-monitoring - Initiated")


EMAIL_SMS_MONITORING <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/email-sms-monitoring.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  as.data.table() , error = function(e) data.frame('EMAIL-SMS-MONITORING' = 'NULL')) 

ANDROIDAPP <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/androidapp.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  as.data.table() , error = function(e) data.frame('ANDROIDAPP' = 'NULL')) 

GOOGLE_SEARCH <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/google_search.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  as.data.table() , error = function(e) data.frame('GOOGLE_SEARCH' = 'NULL')) 

NOT_EMAIL_SMS_ANDROIDAPP <- tryCatch(data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/not_email-sms-monitoring_androidapp.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
)) %>%
  as.data.table() , error = function(e) data.frame('NOT_EMAIL_SMS_ANDROIDAPP' = 'NULL')) 

EMAIL_SMS_MONITORING$Metrics <- 'EMAIL_SMS_MONITORING' 
ANDROIDAPP$Metrics <- 'ANDROIDAPP' 
GOOGLE_SEARCH$Metrics <- 'GOOGLE_SEARCH' 
NOT_EMAIL_SMS_ANDROIDAPP$Metrics <- 'NOT_EMAIL_SMS_ANDROIDAPP' 

EMAIL_SMS <- bind_rows(EMAIL_SMS_MONITORING,ANDROIDAPP,GOOGLE_SEARCH,NOT_EMAIL_SMS_ANDROIDAPP) %>% 
  select(Metrics,c(1:8))

loginfo("Product Yield MIS - Email-sms-monitoring - Completed ")