loginfo("Product Yield MIS - 4-chr-funnel.R Started")

#*******************************************************************************
#*******************************************************************************
## 3. CHR Service Subscriptions =======
#*******************************************************************************
#*******************************************************************************
loginfo("Product Yield MIS - 4-chr-funnel.R - CHR_SUBSCRIPTIONS - started")

start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - DTD'

chr_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'CHR', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#********************************************************************************
start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - MTD'

chr_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'CHR', PERIOD = "MTD")
))
try(logs_to_db(query, start_time))
#********************************************************************************

CHR_SUBSCRIPTIONS <- full_join(chr_dtd, chr_mtd) %>% 
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

# chr_dtd <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
#   list(START_DATE = DATE, END_DATE = DATE + days(1),
#        SERVICE = 'CHR', PERIOD = "Daily")
# ))
# 
# chr_mtd <- data.table(read_sql2(
#   get_conn(),
#   file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
#   list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
#        SERVICE = 'CHR', PERIOD = "MTD")
# ))
# 
# 
# CHR_SUBSCRIPTIONS <- full_join(chr_dtd, chr_mtd) %>% 
#   arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - DTD'

chr_dtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'CHR', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - MTD'

chr_mtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'CHR', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
CHR_SUBSCRIPTIONS_VINTAGE <- full_join(chr_dtd_vin, chr_mtd_vin) %>% 
  arrange(ifelse(`Profiled Month` == 'Total', 'ZZZ', `Profiled Month`))%>% 
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))



loginfo("Product Yield MIS - 4-chr-funnel.R - CHR_SUBSCRIPTIONS - completed")
