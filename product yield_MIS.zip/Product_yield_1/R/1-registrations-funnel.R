loginfo("Product Yield MIS - 1-registrations-funnel.R Started")

#*******************************************************************************
#*******************************************************************************
## 1. Get Data =======
#*******************************************************************************
#*******************************************************************************

#******************************************************
## 1.1 Registrations Funnel  =======
#******************************************************

loginfo("Product Yield MIS - 1-registrations-funnel.R Registrations Query Started")
start_time <- Sys.time()
query = 'registrations-funnel.sql'

reg_raw <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/registrations-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 1-registrations-funnel.R Registrations Query Completed")
#******************************************************
## 1.2 Registrations Funnel  =======
#******************************************************
start_time <- Sys.time()
query = 'mgm-funnel.sql'

mgm_funnel_raw <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/mgm-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 1-registrations-funnel.R MGM Query Started")
#******************************************************
start_time <- Sys.time()
query = 'mgm-actuals.sql'

mgm_actuals_raw <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/mgm-actuals.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 1-registrations-funnel.R MGM Query Completed")

#*******************************************************************************
#*******************************************************************************
## 2. Process =======
#*******************************************************************************
#*******************************************************************************

#******************************************************
## 2.1 Registrations Funnel =======
#******************************************************


compute_funnel <- function(data) {
  
  ROUND_VAL <- 0
  
  result <- data[, .(
    Registrations = sum(!is.na(registration_date)),
    Activations = sum(!is.na(activation_date)),
    `Activations %` = round(sum(!is.na(activation_date)) / sum(!is.na(registration_date)) * 100, ROUND_VAL),
    `Request Report` = sum(!is.na(report_request_date)),
    `Request Report %` = round(sum(!is.na(report_request_date)) / sum(!is.na(activation_date)) * 100, ROUND_VAL),
    `CA Done` = sum(!is.na(profile_date)),
    `CA Done %` = round(sum(!is.na(profile_date)) / sum(!is.na(report_request_date)) * 100, ROUND_VAL),
    Red = sum(!is.na(profile_date) & customer_type == "Red", na.rm = T),
    `Red %` = round(sum(!is.na(profile_date) & customer_type == "Red", na.rm = T) / 
      sum(!is.na(profile_date)) * 100, ROUND_VAL),
    Amber = sum(!is.na(profile_date) & customer_type == "Amber", na.rm = T),
    `Amber %` = round(sum(!is.na(profile_date) & customer_type == "Amber", na.rm = T) / 
                  sum(!is.na(profile_date)) * 100, ROUND_VAL),
    Green = sum(!is.na(profile_date) & customer_type == "Green", na.rm = T),
    `Green %` = round(sum(!is.na(profile_date) & customer_type == "Green", na.rm = T) / 
                        sum(!is.na(profile_date)) * 100, ROUND_VAL)
  )]
  
  return(result)
}

compute_targets <- function(actuals_data, plan_data) {
  # browser()
  res <- plan_data %>% 
    mutate(`Daily Plan` = round(`Monthly Plan` / DAYS_IN_MONTH),
           `MTD Plan` = round(`Monthly Plan` / DAYS_IN_MONTH * DAYS_PAST)) %>% 
    inner_join(actuals_data, by = "Metric") %>% 
    mutate(
        `Month Est` = round(MTD / DAYS_PAST * DAYS_IN_MONTH),
        `Run Rate` = round(ifelse(`Monthly Plan` - `MTD` <= 0, 0,
                            (`Monthly Plan` - `MTD`) / DAYS_LEFT))
        ) %>% 
    right_join(actuals_data, by = c("Metric", "Daily", "MTD")) %>% 
    select(Metric, Daily, `Daily Plan`, MTD, `MTD Plan`, `Month Est`,
           `Monthly Plan`, `Run Rate`)
  
  return(res)
  
}


funnel_cd <- reg_raw %>% 
  .[as_date(registration_date) == DATE] %>% 
  compute_funnel() %>% 
  gather(Metric, Daily)
funnel_mtd <- reg_raw %>% 
  .[is.within.mtd(as_date(registration_date), DATE)] %>% 
  compute_funnel() %>% 
  gather(Metric, MTD)
registration_funnel <- full_join(funnel_cd, funnel_mtd)

REGISTRATION_FUNNEL <- compute_targets(registration_funnel, PLAN_NUMBERS)

#******************************************************
## 3.2 Plot Registrations Funnel =======
#******************************************************


calc_funnel_cols <- function(dat) {
  dat %<>%
    mutate(perc = round(nums / lag(nums) * 100, 0)) %>% 
    mutate(perc = ifelse(is.na(perc), 100, perc)) %>% 
    mutate(dropoff = 100 - perc) %>% 
    mutate(bad = ifelse(dropoff == max(dropoff), "Yes", "No")) %>% 
    mutate(ymin = nums, ymax = lag(nums, default = max(nums))) %>% 
    mutate(funnel_perc = round(nums / max(nums) * 100, 1))
  return(dat)
}

# DataFrame to be used for plotting
plot_df <- funnel_mtd %>% 
  filter(Metric %in% c("Registrations", "Activations", "Request Report", "CA Done")) %>% 
  inner_join(PLAN_NUMBERS) %>% 
  mutate(plan = round(`Monthly Plan` / DAYS_IN_MONTH * DAYS_PAST)) %>% 
  select(metric = Metric, nums = MTD, plan)
  
plot_df$metric <- factor(plot_df$metric, rev(plot_df$metric), ordered = T)
plot_df %<>% calc_funnel_cols

funnel_plot <- ggplot(plot_df) + 
  geom_bar(aes(metric, nums, fill = bad), stat = "identity", width = 0.7) +
  geom_errorbar(aes(x = metric, ymin = plan, ymax = plan), col = "black", size = 1.5) +
  geom_segment(aes(metric,
                   y = ifelse(ymin + 100 >= ymax - 100, NA, ymin + 100),
                   xend = metric,
                   yend = ifelse(ymax - 100 <= ymin + 100, NA, ymax - 100)
  ),
  arrow = arrow(angle = 30, ends = "both", length = unit(0.08, "inches"))) +
  # Absolute numbers in the right most 
  geom_text(aes(metric, y = max(max(plot_df$plan), max(plot_df$nums)) * 1.12, label = nums), fontface = "bold.italic") +
  # The percentages inside the bars
  geom_text(aes(metric, y = nums / 2,
                label = paste(funnel_perc, "%", sep = ""),
                col = bad)) +
  # The percentages in the line segment
  geom_text(aes(metric, (ymax + ymin) / 2,
                label = ifelse(dropoff == 0, NA, paste(dropoff, "%", sep = ""))),
            nudge_x = 0.2) +
  theme_minimal() +
  # geom_hline(yintercept = max(plot_df$nums) * 1.05, size = 1.1) +
  scale_fill_manual(values = c("Yes" = "#DF4150", "No" = "#fcb8be"), guide = F) +
  scale_color_manual(values = c("Yes" = "white", "No" = "black"), guide = F) +
  labs(title = "Registrations MTD Funnel",
       caption = "How to Read:\nThe percentages in the bars represent values as a percentage of the top of the funnel.\n The percentages to the left represent dropoff from the previous stage") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.x = element_blank(),
    axis.title = element_blank(),
    axis.text.y = element_text(face = "bold"),
    plot.caption = element_text(size = 8)
  ) +
  coord_flip() 

funnel_image_fname <- file.path(
  DATA_PATH,
  'registrations_funnel_mtd.png'
)

ggsave(funnel_image_fname, funnel_plot, width = 8, height = 3, dpi = 100)

#******************************************************
## 3.3 Process MGM =======
#******************************************************

mgm_funnel_cd <- mgm_funnel_raw %>% 
  .[as_date(registration_date) == DATE,
    .(`MGM Registrations` = .N, `MGM Profiling` = sum(!is.na(profiled_on)),
      `Profiling %` = round(sum(!is.na(profiled_on)) / .N * 100, 0))]

mgm_funnel_mtd <- mgm_funnel_raw %>% 
  .[,.(`MGM Registrations` = .N, `MGM Profiling` = sum(!is.na(profiled_on)),
       `Profiling %` = round(sum(!is.na(profiled_on)) / .N * 100, 0))]

mgm_actuals_cd <- mgm_actuals_raw %>% 
  .[as_date(profiled_on) == DATE,
    .(Metric = "MGM Profiling (Actuals)",
      Daily = n_distinct(user_id, na.rm = T))]

mgm_actuals_mtd <- mgm_actuals_raw %>% 
  .[is.within.mtd(as_date(profiled_on), DATE),
    .(Metric = "MGM Profiling (Actuals)",
      MTD = n_distinct(user_id, na.rm = T))]

MGM_FUNNEL <- full_join(gather(mgm_funnel_cd, Metric, Daily),
                        gather(mgm_funnel_mtd, Metric, MTD)) %>% 
  bind_rows(full_join(mgm_actuals_cd, mgm_actuals_mtd)) %>% 
  compute_targets(PLAN_NUMBERS)

loginfo("Product Yield MIS - 1-registrations-funnel.R completed")
