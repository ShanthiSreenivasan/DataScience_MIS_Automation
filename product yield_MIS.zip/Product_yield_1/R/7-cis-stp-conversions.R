loginfo("Product Yield MIS - 7-cis-stp-conversions.R Started")

#*******************************************************************************
#*******************************************************************************
## 1. Get Data =======
#*******************************************************************************
#*******************************************************************************

loginfo("Product Yield MIS - 6-cis-stp-conversions.R Login Metrics Queries Started")
start_time <- Sys.time()
query = 'cis-stp-subs-funnel.sql'

CIS_STP_SUBS <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/cis-stp-subs-funnel.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
)) %>% 
  .[order(-saleable_profiles)] %>% 
  rename(Source = utm, Profiles = profiles, Saleable = saleable_profiles,
         `Subscribed Users` = subbed_users, `Subscribed Accounts` = accounts)

try(logs_to_db(query, start_time))
#******************************************************************************** 