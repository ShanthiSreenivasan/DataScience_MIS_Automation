loginfo("Product Yield MIS - 5-bys-funnel.R Started")

#*******************************************************************************
#*******************************************************************************
## 3. BYS Actuals =======
#*******************************************************************************
#*******************************************************************************
loginfo("Product Yield MIS - 5-bys-funnel.R BYS Actuals Started")

start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - DTD'

bys_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - MTD'

bys_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
BYS_SUBSCRIPTIONS <- full_join(bys_dtd, bys_mtd) %>% 
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - DTD'

bys_dtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - MTD'

bys_mtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'BYS', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 

BYS_SUBSCRIPTIONS_VINTAGE <- full_join(bys_dtd_vin, bys_mtd_vin)  %>% 
  arrange(ifelse(`Profiled Month` == 'Total', 'ZZZ', `Profiled Month`))%>%  
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

loginfo("Product Yield MIS - 5-bys-funnel.R BYS Actuals Completed")




loginfo("Product Yield MIS - 5-IDPP-funnel.R BYS Actuals Started")

start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - DTD'

idpp_dtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'IDPP', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions.sql - MTD'

idpp_mtd <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'IDPP', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
IDPP_SUBSCRIPTIONS <- full_join(idpp_dtd, idpp_mtd) %>% 
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - DTD'

idpp_dtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1),
       SERVICE = 'IDPP', PERIOD = "Daily")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
start_time <- Sys.time()
query = 'chr-bys-subscriptions-vintage.sql - MTD'

idpp_mtd_vin <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/chr-bys-subscriptions-vintage.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1),
       SERVICE = 'IDPP', PERIOD = "MTD")
))

try(logs_to_db(query, start_time))
#******************************************************************************** 

IDPP_SUBSCRIPTIONS_VINTAGE <- full_join(idpp_dtd_vin, idpp_mtd_vin)  %>% 
  arrange(ifelse(`Profiled Month` == 'Total', 'ZZZ', `Profiled Month`))%>%  
  arrange(ifelse(OIC == 'Total', 'ZZZ', OIC))

loginfo("Product Yield MIS - 5-bys-funnel.R BYS Actuals Completed")
