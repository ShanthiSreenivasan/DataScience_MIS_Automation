loginfo("Product Yield MIS - 6-login-metrics.R Started")

loginfo("Product Yield MIS - 6-login-metrics.R Reprofiled Login Metrics Queries Started")

loginfo("Product Yield MIS - 6-login-metrics.R Reprofiled Logins DTD Query Started")
start_time <- Sys.time()
query = 'reprofiled-logins-daily.sql'

REPROFILED_LOGINS_DAILY <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/reprofiled-logins-daily.sql'),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
loginfo("Product Yield MIS - 6-login-metrics.R Reprofiled Logins DTD Query Completed")
#******************************************************************************** 
loginfo("Product Yield MIS - 6-login-metrics.R Reprofiled Logins MTD Query Started")
start_time <- Sys.time()
query = 'reprofiled-logins.sql - MTD'

REPROFILED_LOGINS_MTD <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, 'queries/reprofiled-logins.sql'),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

try(logs_to_db(query, start_time))
#******************************************************************************** 
loginfo("Product Yield MIS - 6-login-metrics.R Reprofiled Logins MTD Query Completed")
