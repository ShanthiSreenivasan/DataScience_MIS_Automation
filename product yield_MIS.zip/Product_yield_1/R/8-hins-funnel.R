#' HINS Funnel


HINS_SUBSCRIPTIONS_DTD <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, "queries/hins_funnel.sql"),
  list(START_DATE = DATE, END_DATE = DATE + days(1))
))

if(nrow(HINS_SUBSCRIPTIONS_DTD) == 0){
  
  HINS_SUBSCRIPTIONS_DTD = data.table(`Customer Type` = character(0), `HINS WITH CHR` = numeric(0),
                           `HINS WITH BYS` = numeric(0), `HINS WITHOUT CHR/BYS` = numeric(0))
  
}


HINS_SUBSCRIPTIONS_MTD <- data.table(read_sql2(
  get_conn(),
  file.path(MIS_PATH, "queries/hins_funnel.sql"),
  list(START_DATE = MONTH_START, END_DATE = DATE + days(1))
))

if(nrow(HINS_SUBSCRIPTIONS_MTD) == 0){
  
  HINS_SUBSCRIPTIONS_MTD = data.table(`Customer Type` = character(0), `HINS WITH CHR` = numeric(0),
                                      `HINS WITH BYS` = numeric(0), `HINS WITHOUT CHR/BYS` = numeric(0))
  
}
