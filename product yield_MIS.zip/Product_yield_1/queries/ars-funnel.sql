WITH leads_base as (
    SELECT cl.lead_id,
		   cll.log_updated_at
    FROM
            cis.collections_leads cl
	LEFT JOIN LATERAL(
						SELECT log_updated_at,
						       updated_by_oic
						FROM consolidated_ars_lead_logs
						WHERE lead_id = cl.lead_id
						AND product_status ~* '320'
						AND lead_log_type ~* 'product status change'
						ORDER BY log_updated_at 
						LIMIT 1
						) cll on true
    WHERE
        cl.bank_feedback_date >= '{{START_DATE}}'
        and cl.bank_feedback_date < '{{END_DATE}}'
		    --and cll.updated_by_oic ~* 'System'
)
SELECT
    count(*) as "Yet to make payment and upload pop - 320",
    count(*) filter (where oic_at_341 = 'System') as "Full Payment Selected - 341",
    (1 - round(
        count(*) filter (where oic_at_341 = 'System') / 
        nullif(count(*),0)::numeric, 3
    )) * 100 || ' %' as "Payment selection page Dropoff %",
    count(*) filter (where oic_at_349 = 'System') as "Looked at Payment Mode - 349",
    (1 - round(
        count(*) filter (where oic_at_349 = 'System') / 
        nullif(count(*) filter (where oic_at_341 = 'System'),0)::numeric, 3
    )) * 100 || ' %' as "Payment Mode Selection Dropoff %",
    count(*) filter (where oic_at_350 = 'System') as "Paid but pop unavailable - 350",
    (1- round(
        count(*) filter (where oic_at_350 = 'System') / 
        nullif(count(*) filter (where oic_at_349 = 'System'),0)::numeric, 3
    )) * 100 || ' %' as "ARS Paid Dropoff %",
	count(*) filter (where oic_at_351 = 'System') as "CM validation pending - 351",
    (1- round(
        count(*) filter (where oic_at_351 = 'System') / 
        nullif(count(*) filter (where oic_at_350 = 'System'),0)::numeric, 3
    )) * 100 || ' %' as "POP Upload Dropoff %"
FROM 
	leads_base cl
    LEFT JOIN LATERAL (
        SELECT 
            min(log_updated_at) filter (where product_status ~*  '341') pass_341_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '341'))[1] as oic_at_341,        
            min(log_updated_at) filter (where product_status ~*  '349') pass_349_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '349'))[1] as oic_at_349,  
            min(log_updated_at) filter (where product_status ~*  '350') pass_350_date,        
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '350'))[1] as oic_at_350,
            min(log_updated_at) filter (where product_status ~*  '351') pass_351_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '351'))[1] as oic_at_351
        FROM
            consolidated_ars_lead_logs
        WHERE
            lead_id = cl.lead_id
            and log_updated_at >= cl.log_updated_at
			and lead_log_type ~* 'product status change'
			and log_updated_at >= '{{START_DATE}}'
            and log_updated_at < '{{END_DATE}}'
            and updated_by_oic ~* 'System'
    ) cll2 ON TRUE