SELECT 
	l.user_id,
    l.id lead_id,
    l.created_at registration_date,
    ll.*,
    case when cp.p_customer_type =1 then 'Green'
    when cp.p_customer_type =2 then 'Red'
    when cp.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type,
    cp.is_saleable
from
    leads l
    left join lateral (
        SELECT 
            min(ll.updated_at) filter (where cs.status_code = '50') activation_date,
            min(ll.updated_at) filter (where cs.status_code = '51ET') report_request_date,
            min(ll.updated_at) filter (where cs.status_code in ('55E', '55ET')) profile_date
        FROM
            lead_logs ll
            LEFT JOIN
                master_tables.cmol_status as cs
                ON cs.id = ll.cmol_status_id
        WHERE
            lead_id = l.id
    ) ll on true
    LEFT JOIN  
        cm_cp_processed cp
        on cp.user_id = l.user_id
        and cp.customer_profile_id = (SELECT min(customer_profile_id) FROM cm_cp_processed WHERE user_id = cp.user_id)
WHERE 
  l.type = 'User'
  and l.created_at >= '{{ START_DATE }}'
  and l.created_at < '{{ END_DATE }}'