WITH base AS (
    SELECT
        usl.user_id,
        usl.utm_source,
        usl.created_at        
    FROM
    usl_currentmonth usl
    WHERE
        usl.utm_source_text IN ('email-monitoring-red','sms-monitoring')     
        AND usl.created_at >= '{{ START_DATE }}'
        AND usl.created_at < '{{ END_DATE }}'
        --LIMIT 1000
), base2 AS (
    SELECT
        b.*,
        cp.customer_profile_id,
        cp.created_on
    FROM 
        base b
        INNER JOIN 
            cm_cp_processed cp
            ON cp.user_id = b.user_id
            AND cp.customer_profile_id = (SELECT customer_profile_id FROM cm_cp_processed WHERE user_id = cp.user_id AND is_active = 1 ORDER BY created_on DESC LIMIT 1)
            AND cp.p_customer_type = 2
)
SELECT
    COUNT(b.user_id) as total_logins,
    COUNT(distinct b.user_id) as unique_logins,
    
    COUNT(b.user_id) FILTER (WHERE nsaleable > 0) as total_nsaleable_logins,
    COUNT(distinct b.user_id) FILTER (WHERE nsaleable > 0) as unique_nsaleable_logins,
    
    sum(has_pass_050) as total_has_pass_050,
    COUNT(distinct b.user_id) FILTER (WHERE has_pass_050 = 1) as has_pass_050,
    
    sum(has_cis_sub) as total_has_cis_sub,
    COUNT(distinct b.user_id) FILTER (WHERE has_cis_sub = 1) as unique_has_cis_sub
FROM 
    base2 b
    LEFT JOIN LATERAL(
        SELECT
            bool_or(product_status ~* 'CIS(.*?)050')::integer as has_pass_050
        FROM 
            consolidated_cis_lead_logs cll
        WHERE
            cll.user_id = b.user_id
            AND cll.log_updated_at < b.created_at + interval '15 minutes'
            AND cll.log_updated_at >= b.created_at - interval '1 minutes'
    ) cll ON TRUE
    LEFT JOIN LATERAL(
        SELECT
            bool_or(user_id is not null)::integer as has_cis_sub
        FROM 
            cis.cis_subscriptions cis
        WHERE   
            cis.user_id = b.user_id
            AND cis.payment_date < b.created_at + interval '15 minutes'
            AND cis.payment_date >= b.created_at - interval '1 minutes'
            AND cis.order_total > 0
    ) cis ON TRUE
    left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1 
            LEFT JOIN LATERAL (
                SELECT
                    case when las.is_customer = 1 and las.enable_diy = 1 then 1 else 0 end as is_ldb
                FROM
                    master_tables.lender_account_status las 
                WHERE 
                    las.product_family_id = cpa.product_family_id 
                    AND las.lender_id = cpa.lender_id 
                    AND las.account_status_id = cpa.account_status_master_id
                LIMIT 1
            ) ldb_stat on true
        where
            customer_profile_id = b.customer_profile_id
    ) cpa on true