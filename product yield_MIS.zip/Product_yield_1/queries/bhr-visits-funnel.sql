select
  '{{VAR}}' as "Metrics",
	count(*) filter(where bhr_common_page_visited = 1 ) as "BHR Common Page Visit (030)",
	count(*) filter(where bhr_visited = 1 ) as "BHR Page Visit (040)",
	count(*) filter(where pay_now = 1 ) as "Payment Page (050)",
	count(*) filter(where made_payment =1 ) as "Payment Made (070)"
	
from
	(
		select distinct on (user_id, date(log_updated_at))
			user_id, log_updated_at as bhr_visit_date
		from consolidated_cis_lead_logs
		where
			product_status ~* 'BHR'
			and log_updated_at >= '{{START_DATE}}' 
			and log_updated_at < '{{END_DATE}}'
		order by user_id
	) cc
	left join lateral (
		select 
			bool_or(product_status ~* 'BHR-PP-XX-030')::integer bhr_common_page_visited,
			bool_or(product_status ~* 'BHR-PP-XX-040')::integer bhr_visited,
			bool_or(product_status ~* 'BHR-PP-XX-050')::integer pay_now,
			bool_or(product_status ~* 'BHR-DX-XX-070')::integer made_payment,
			bool_or(product_status ~* 'BHR-DX-XX-100')::integer made_payment_100			
		from 
			consolidated_cis_lead_logs
		where
			user_id = cc.user_id
			and log_updated_at >= bhr_visit_date
			and log_updated_at < '{{END_DATE}}'
	) cll on true
