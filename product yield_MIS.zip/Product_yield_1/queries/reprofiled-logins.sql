WITH results AS (
    select
        case when cp.p_customer_type =1 then 'Green'
    when cp.p_customer_type =2 then 'Red'
    when cp.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type,
        count(distinct cp.user_id) reprofiled,
        count(distinct cp.user_id) filter (where exists (
            select 1 
            from usl_currentmonth 
            where 
                user_id = cp.user_id
                and created_at >= cp.created_on
                and created_at >= '{{START_DATE}}'::DATE 
                and created_at < '{{END_DATE}}'::DATE
        )) logged_in
    from 
        cm_cp_processed cp
    where
        --cp.customer_profile_id = (SELECT max(customer_profile_id) FROM cm_cp_processed WHERE user_id = cp.user_id)
        --and (select min(customer_profile_id) from cm_cp_processed where user_id = cp.user_id) != cp.customer_profile_id
        (select count(*) from cm_cp_processed where user_id = cp.user_id) > 1
        and cp.p_customer_type is not null
        and cp.created_on >= '{{ START_DATE }}'
        AND cp.created_on < '{{ END_DATE }}'
    group by
        rollup(cp.p_customer_type)
)
SELECT
    customer_type as "Customer Type",
    reprofiled as "Reprofiled",
    logged_in as "Logged In",
    case when reprofiled::numeric!=0
    then round(logged_in / reprofiled::numeric * 100, 2) || '%' 
    end as "Logged In %"
FROM
    results
