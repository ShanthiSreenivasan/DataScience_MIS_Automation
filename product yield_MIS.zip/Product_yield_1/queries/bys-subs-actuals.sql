SELECT
	count(distinct o.id) filter (where date(payment_date) = '{{END_DATE}}') daily_orders,
	count(distinct o.id) mtd_orders
FROM 
	orders o
where
	o.service_type = 'BYS'
	and date(payment_date) between '{{START_DATE}}' and '{{END_DATE}}'
