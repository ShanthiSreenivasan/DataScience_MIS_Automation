select
  '{{VAR}}' as "Metrics",
	count(*) filter(where bhrl_common_page_visited = 1 ) as "BHR Common Page Visit (030)",
	count(*) filter(where bhrl_visited = 1 ) as "BHRL Page Visit (040)" ,
	count(*) filter(where pay_now = 1 ) as "Payment Page (050)",
	count(*) filter(where made_payment =1 ) as "Payment Made (070)"
from
	(
		select distinct on (user_id, date(log_updated_at))
			user_id, log_updated_at bhrl_visit_date
		from consolidated_lead_logs
		where
			product_status ~* 'BHR'
			and log_updated_at >= '{{START_DATE}}' 
			and log_updated_at < '{{END_DATE}}'
		order by user_id
	) cc
	left join lateral (
		select 
			bool_or(product_status ~* 'BHR-PP-XX-030')::integer bhrl_common_page_visited,
			bool_or(product_status ~* 'BHRL-PP-XX-040')::integer bhrl_visited,
			bool_or(product_status ~* 'BHRL-PP-XX-050')::integer pay_now,
			bool_or(product_status ~* 'BHRL-DX-XX-070')::integer made_payment,
			bool_or(product_status ~* 'BHRL-DX-XX-100')::integer made_payment_100

		from 
			consolidated_lead_logs
		where
			user_id = cc.user_id
			and log_updated_at >= bhrl_visit_date
			and log_updated_at < '{{END_DATE}}'
	) cll on true
group by 1