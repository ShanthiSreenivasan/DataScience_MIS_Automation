SELECT
ps.status_text as "Product Status Moved To",
prev_status.status_text as "Product Status Moved From",
AVG(date_part('day', (psl.created_at - prev_status.created_at))) as "Average days from Previous Status",
COUNT(DISTINCT cl.lead_id) as "# Leads Moved"
FROM cis.collections_leads cl
INNER JOIN payment_status_logs psl
ON cl.lead_id = psl.lead_id
LEFT JOIN master_tables.payment_status ps 
ON psl.payment_status_id = ps.id
LEFT JOIN LATERAL (
  SELECT pays.status_text,
  pastlog.created_at
  FROM payment_status_logs pastlog
  LEFT JOIN master_tables.payment_status pays 
  ON pastlog.payment_status_id = pays.id
  WHERE pastlog.lead_id = cl.lead_id
  AND pastlog.created_at < psl.created_at
  AND pastlog.internal_user_id = 9999
) prev_status on true
WHERE EXISTS (SELECT 1 FROM consolidated_ars_lead_logs WHERE lead_id = cl.lead_id AND product_status ~* '345' LIMIT 1)
AND psl.created_at >= '{{START_DATE}}'
AND psl.created_at < '{{END_DATE}}'
AND psl.internal_user_id = 9999
AND psl.created_at = (SELECT max(created_at)
                      FROM payment_status_logs
                      WHERE lead_id = cl.lead_id
                      AND psl.created_at >= '{{START_DATE}}'
                      AND psl.created_at < '{{END_DATE}}'
                      AND psl.internal_user_id = 9999
)
GROUP BY 1,2
ORDER BY 1,2