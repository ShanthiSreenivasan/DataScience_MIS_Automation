SELECT  
      COUNT(DISTINCT user_id) filter(WHERE uso.service_expiry_date::date = '{{EXPIRY_DATE}}') AS "Emails to be Sent",
	  COUNT(DISTINCT user_id) filter(WHERE renewal_login_date::date >= '{{MONTH_START}}') AS "MTD Login from Mail",
	  COUNT(DISTINCT user_id) filter(WHERE renewal_login_date::date >= '{{START_DATE}}') AS "DTD Login from Mail",
      COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{MONTH_START}}') AS "MTD - CHR Renewal",
	  COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{MONTH_START}}' AND utm_latest.utm_source_text = 'CHR_renewal') AS "MTD - CHR Renewal from System Mail",
	  COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{MONTH_START}}' AND utm_latest.utm_source_text != 'CHR_renewal') AS "MTD - CHR Renewal not from System Mail",
      COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{START_DATE}}') AS "DTD - CHR Renewal",
      COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{START_DATE}}' AND utm_latest.utm_source_text = 'CHR_renewal') AS "DTD - CHR Renewal from System Mail",
      COUNT(DISTINCT user_id) filter(WHERE payment_date::date >= '2019-12-14' AND order_total > 0 AND chr.flag = 1 AND payment_date::date >= '{{START_DATE}}' AND utm_latest.utm_source_text != 'CHR_renewal') AS "DTD - CHR Renewal not from System Mail"
FROM product.vas_subscriptions vas
LEFT JOIN LATERAL (SELECT service_expiry_date from user_service_orders where id = vas.user_service_order_id limit 1) uso on true
LEFT JOIN LATERAL (SELECT utm_source_text
                   FROM utm_source_log
                   WHERE user_id = vas.user_id
                   AND created_at <= vas.payment_date
                   ORDER BY created_at DESC
                   LIMIT 1
                   ) utm_latest ON TRUE	
LEFT JOIN LATERAL (SELECT created_at as renewal_login_date
                   FROM utm_source_log
                   WHERE user_id = vas.user_id
		   AND utm_source_text = 'CHR_renewal'
                   ORDER BY created_at DESC
                   LIMIT 1
                   ) u ON TRUE	
LEFT JOIN LATERAL (SELECT 1 as flag
                   FROM product.vas_subscriptions
                   WHERE user_id = vas.user_id
                   AND service_type = 'CHRA'
                   AND payment_date <= vas.payment_date
                   AND order_total > 0
                   AND user_service_order_id != vas.user_service_order_id
                   LIMIT 1
                   ) chr ON TRUE						
WHERE service_type = 'CHRA'