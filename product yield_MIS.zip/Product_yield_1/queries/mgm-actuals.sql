SELECT 
	ur.user_id,
    ur.created_at registration_date,
    cp.created_on profiled_on,
    case when cp.p_customer_type =1 then 'Green'
    when cp.p_customer_type =2 then 'Red'
    when cp.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type
FROM
    user_referrals ur
    left join 
        cm_cp_processed cp
        ON cp.user_id = ur.user_id
        AND cp.customer_profile_id = (select min(customer_profile_id) from cm_cp_processed where user_id = cp.user_id)
WHERE
    cp.created_on >= '{{ START_DATE }}' 
    and cp.created_on < '{{ END_DATE }}'