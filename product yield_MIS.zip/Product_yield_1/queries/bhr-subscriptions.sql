
SELECT
	o.user_id,
	o.lead_id,
    o.payment_date,
	o.service_type,
    CASE
        WHEN usl.utm_source_text ~* '(^cis-pa|^email|^sms|sms$)' and usl.utm_source_text !~* 'monitoring' then 'PORTFOLIO'
        WHEN usl.utm_source_text ~* '^(CRM|byssms|chrsms)-(?=.*[0-9].*)(?=.*[A-Z].*)[A-Z0-9]+$' THEN substring(usl.utm_source_text from '-([A-Z0-9]+)$')
        WHEN usl.utm_source_text ~ '^(?=.*[0-9].*_)(?=.*[A-Z].*_)[A-Z0-9]+_androidapp' THEN substring(usl.utm_source_text from '^([A-Z0-9]+)_')
        WHEN lc.oic IS NOT NULL THEN lc.oic
        WHEN usl.utm_source_text ~* '(monitoring|^email-[RAG]2[RAG][di]?|^email-chra|^email-cis-(310|350|4050))' then 'System'
        ELSE 'System'
    END AS sub_oic,
    case when cp.p_customer_type =1 then 'Green'
    when cp.p_customer_type =2 then 'Red'
    when cp.p_customer_type =3 then 'Amber'
    else 'NH' end as customer_type
FROM
    orders o
	LEFT JOIN
		user_service_orders uso
		on uso.order_payment_id = o.id
    LEFT JOIN LATERAL (
        select 
            utm_source_text,
            created_at as login_date
        from 
            utm_source_log 
        where
            user_id = o.user_id
            and created_at < o.payment_date
        order by 
            created_at desc
        limit 1
    ) usl on true
    LEFT JOIN LATERAL (
        SELECT oic 
        FROM leads l inner join lead_contacts lc on l.id = lc.lead_id 
        WHERE 
            l.user_id = o.user_id
            and description ~* '(bhr)' 
            and lc.updated_at >= (o.payment_date - interval '48 hours') 
            and lc.updated_at < o.payment_date 
            and lc.contact_type ~* 'sms'
        ORDER BY 
            lc.updated_at 
        LIMIT 1
    ) lc ON TRUE
    LEFT JOIN 
        cm_cp_processed cp
        ON cp.user_id = o.user_id
        AND cp.customer_profile_id = (SELECT MAX(customer_profile_id) FROM cm_cp_processed WHERE user_id = o.user_id and created_on < o.payment_date)
WHERE
    o.service_type = 'BHR'
    and o.order_status_id in (2, 7, 8, 11)
    AND o.payment_date >= '{{START_DATE}}'
    AND o.payment_date < '{{END_DATE}}'