SELECT
    count(*) as "Red Unique Logins",
    count(*) filter (where saleable_accounts > 0) as "Red (Saleable) Unique Logins",
    count(*) filter (where oic_at_040 = 'System') as "CIS Page Visits - 040",
    (1 - round(
        count(*) filter (where oic_at_040 = 'System') / 
        count(*) filter (where saleable_accounts > 0)::numeric, 3
    )) * 100 || ' %' as "CIS Page Visits Dropoff %",
    count(*) filter (where oic_at_050 = 'System') as "Payment Page - 050",
    (1 - round(
        count(*) filter (where oic_at_050 = 'System') / 
        count(*) filter (where oic_at_040 = 'System')::numeric, 3
    )) * 100 || ' %' as "Payment Page Dropoff %",
    count(*) filter (where oic_at_070 = 'System') as "CIS Paid - 070",
    (1- round(
        count(*) filter (where oic_at_070 = 'System') / 
        count(*) filter (where oic_at_050 = 'System')::numeric, 3
    )) * 100 || ' %' as "CIS Paid Dropoff %"
   
FROM 
    test.cis_visit_funnel rl
    LEFT JOIN LATERAL (
        SELECT 
            min(log_updated_at) filter (where product_status ~*  '000') pass_000_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '000'))[1] as oic_at_000,        
            min(log_updated_at) filter (where product_status ~*  '040') pass_040_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '040'))[1] as oic_at_040,  
            min(log_updated_at) filter (where product_status ~*  '050') pass_050_date,        
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '050'))[1] as oic_at_050,
            min(log_updated_at) filter (where product_status ~*  '070') pass_070_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '070'))[1] as oic_at_070
        FROM
            consolidated_cis_lead_logs
        WHERE
            user_id = rl.user_id 
            and log_updated_at >= rl.login_date
            AND product_status ~* '(CIS|DIS)'
    ) cll ON TRUE
WHERE 
    login_date >= '{{START_DATE}}'
    AND login_date < '{{END_DATE}}'