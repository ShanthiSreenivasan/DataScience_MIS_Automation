SELECT
split_part(cll.product_status,'-',4) as "Product Status Moved To",
split_part(c.product_status,'-',4) as "Product Status Moved From",
avg(date_part('day', (cll.log_updated_at - c.log_updated_at))) as "Average days from Previous Status",
count(distinct cll.lead_id) as "# Leads Moved"
FROM 
consolidated_ars_lead_logs cll
LEFT JOIN LATERAL (SELECT product_status,
                   log_updated_at
                   FROM consolidated_ars_lead_logs
                   WHERE lead_id = cll.lead_id
                   AND lead_log_type ~* 'product status change'
                   AND updated_by_oic ~* 'System'
                   AND log_updated_at < cll.log_updated_at
                   ORDER by log_updated_at DESC
                   LIMIT 1
) c on true
WHERE
lead_log_type ~* 'product status change'
AND cll.log_updated_at >= '{{START_DATE}}'
AND cll.log_updated_at < '{{END_DATE}}'
AND updated_by_oic ~* 'System'
AND cll.log_updated_at = (SELECT max(log_updated_at)
                          FROM consolidated_ars_lead_logs
                          WHERE lead_id = cll.lead_id
                          AND lead_log_type ~* 'product status change'
                          AND cll.log_updated_at >= '{{START_DATE}}'
                          AND cll.log_updated_at < '{{END_DATE}}'
                          AND updated_by_oic ~* 'System')
GROUP BY 1,2
ORDER BY 1,2