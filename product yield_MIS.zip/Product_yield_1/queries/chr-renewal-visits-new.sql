WITH eligible AS (
    SELECT
        COUNT(distinct user_id) as "LTD - CHR Renewal Eligible Customers",
        COUNT(distinct user_id) FILTER (WHERE uso.service_expiry_date >= '{{ NXT_MONTH_START }}' AND uso.service_expiry_date < '{{ NXT_END_START }}') as "MTD - CHR Renewal Eligible Customers",
        COUNT(distinct user_id) FILTER (WHERE uso.service_expiry_date >= '{{ NXT_DTD_START }}' AND uso.service_expiry_date < '{{ NXT_END_START }}') as "DTD - CHR Renewal Eligible Customers"
    FROM 
        user_service_orders uso
    WHERE
        id = (SELECT id FROM user_service_orders WHERE user_id = uso.user_id AND service_type IN ('CHR','CHRA') ORDER BY id DESC LIMIT 1)
        AND uso.service_type IN ('CHR','CHRA')
        AND uso.service_expiry_date < '{{ NXT_END_START }}'
), logins AS (
-- Logins
SELECT
    COUNT(distinct user_id) as "MTD - CHR Renewal Logins",
    COUNT(distinct user_id) FILTER (WHERE usl.created_at >= '{{ DTD_DATE }}' AND usl.created_at < '{{ END_DATE }}') as "DTD - CHR Renewal Logins"
FROM 
    usl_currentmonth usl
WHERE
    usl.utm_source IN ('CHR_renewal_E1','CHR_renewal_E2','CHR_renewal_E3','CHR_renewal_E4','CHR_renewal_E5','CHR_renewal_E6','CHR_renewal_E7','CHR_renewal_E8','CHR_renewal_E9','CHR_renewal_E10','CHR_renewal_E11','CHR_renewal_S1','CHR_renewal_S2','CHR_renewal_S3','CHR_renewal_S4','CHR_renewal_S5','CHR_renewal_S6','CHR_renewal_S7','CHRA_RENEWAL_S8','CHR_renewal_S9','CHR_renewal_S10','CHR_renewal_S11')
    AND usl.created_at >= '{{ MONTH_START }}'
    AND usl.created_at < '{{ END_DATE }}'
), conversion AS (
-- Conversions
SELECT
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1) AS "MTD - CHR Renewal",
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1 AND utm_latest.utm_source_text ~* 'CHR_renewal_(S|E)') AS "MTD - CHR Renewal from System Mail",
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1 AND utm_latest.utm_source_text !~* 'CHR_renewal_(S|E)') AS "MTD - CHR Renewal from not System Mail",
    
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1 AND payment_date >= '{{ DTD_DATE }}' AND payment_date < '{{ END_DATE }}') AS "DTD - CHR Renewal",
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1 AND payment_date >= '{{ DTD_DATE }}' AND payment_date < '{{ END_DATE }}' AND utm_latest.utm_source_text ~* 'CHR_renewal_(S|E)') AS "DTD - CHR Renewal from System Mail",
    COUNT(DISTINCT user_id) filter(WHERE order_total > 0 AND chr.flag = 1 AND payment_date >= '{{ DTD_DATE }}' AND payment_date < '{{ END_DATE }}' AND utm_latest.utm_source_text !~* 'CHR_renewal_(S|E)') AS "DTD - CHR Renewal from not System Mail"
FROM 
    product.vas_subscriptions vas
    LEFT JOIN LATERAL (
        SELECT 
            1 as flag
        FROM 
            product.vas_subscriptions
        WHERE 
            user_id = vas.user_id
            AND service_type = 'CHRA'
            AND payment_date <= vas.payment_date
            AND order_total > 0
            AND user_service_order_id != vas.user_service_order_id
        LIMIT 1
    ) chr ON TRUE
    LEFT JOIN LATERAL (
        SELECT 
            utm_source_text
        FROM 
            usl_currentmonth
        WHERE   
            user_id = vas.user_id
            AND created_at <= vas.payment_date
        ORDER BY 
            created_at DESC
        LIMIT 1
    ) utm_latest ON TRUE
WHERE
    vas.service_type = 'CHRA'
    AND vas.payment_date >= '{{ MONTH_START }}'
    AND vas.payment_date < '{{ END_DATE }}'
)

SELECT
    e.*,
    l.*,
    c.*
FROM 
    eligible e, logins l, conversion c
