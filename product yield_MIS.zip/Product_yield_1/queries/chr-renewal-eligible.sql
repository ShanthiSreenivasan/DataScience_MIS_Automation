SELECT
    COUNT(distinct user_id) as "LTD - CHR Renewal Eligible Customers",
    COUNT(distinct user_id) FILTER (WHERE uso.service_expiry_date >= '{{ NXT_MONTH_START }}' AND uso.service_expiry_date < '{{ NXT_MONTH_END }}') as "MTD - CHR Renewal Eligible Customers",
    COUNT(distinct user_id) FILTER (WHERE uso.service_expiry_date >= '{{ NXT_DTD_START }}' AND uso.service_expiry_date < '{{ NXT_MONTH_END }}') as "DTD - CHR Renewal Eligible Customers"
FROM 
    user_service_orders uso
WHERE
    id = (SELECT id FROM user_service_orders WHERE user_id = uso.user_id AND service_type IN ('CHR','CHRA') ORDER BY id DESC LIMIT 1)
    AND uso.service_type IN ('CHR','CHRA')
    AND uso.service_expiry_date < '{{ NXT_MONTH_END }}'