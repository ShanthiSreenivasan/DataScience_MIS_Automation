WITH red_profiles AS (
    select
        cp.user_id,
        cp.created_on as profile_date,
        acc.nsaleable as saleable_accounts
    from 
        cm_cp_processed cp
        left join lateral (
		select count(*) as nsaleable
		from cm_ccap_processed cpa
				left join master_tables.lenders len
					on len.id = cpa.lender_id
				inner join master_tables.account_status acs
					on acs.id = cpa.p_account_status
					inner join master_tables.account_types at2 
					on at2.account_type_id=cpa.p_account_type
				inner join master_tables.lender_saleable_accounts lsa
					on lsa.lender_id = cpa.lender_id
				and lsa.product_family_id = cpa.product_family_id
				and lsa.account_status_id = acs.id
				and lsa.account_status_id not in (2,3,7,8,22,21)
				and lsa.is_active = 1
				WHERE
                cp.customer_profile_id = customer_profile_id
        ) acc ON TRUE
    where
        cp.customer_profile_id = (
            select min(customer_profile_id) 
            from cm_cp_processed 
            where user_id = cp.user_id
        )
        and cp.created_on >= '{{ START_DATE }}'
        and cp.created_on < '{{ END_DATE }}'
        and cp.p_customer_type = 2
)
SELECT
    count(*) as "Red Profiles",
    count(*) filter (where saleable_accounts > 0) as "Red (Saleable) Profiles",
    count(*) filter (where oic_at_040 = 'System') as "CIS Page Visits - 040",
    (1 - round(
        count(*) filter (where oic_at_040 = 'System') / 
        count(*) filter (where saleable_accounts > 0)::numeric, 3
    )) * 100 || ' %' as "CIS Page Visits Dropoff %",
    count(*) filter (where oic_at_050 = 'System') as "Payment Page - 050",
    (1 - round(
        count(*) filter (where oic_at_050 = 'System') / 
        count(*) filter (where oic_at_040 = 'System')::numeric, 3
    )) * 100 || ' %' as "Payment Page Dropoff %",
    count(*) filter (where oic_at_070 = 'System') as "CIS Paid - 070",
    (1- round(
        count(*) filter (where oic_at_070 = 'System') / 
        count(*) filter (where oic_at_050 = 'System')::numeric, 3
    )) * 100 || ' %' as "CIS Paid Dropoff %"
FROM 
    red_profiles rl
    LEFT JOIN LATERAL (
        SELECT 
            min(log_updated_at) filter (where product_status ~*  '^[cd]is.*000') pass_000_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^[cd]is.*000'))[1] as oic_at_000,        
            min(log_updated_at) filter (where product_status ~*  '^[cd]is.*040') pass_040_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^[cd]is.*040'))[1] as oic_at_040,  
            min(log_updated_at) filter (where product_status ~*  '^[cd]is.*050') pass_050_date,        
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^[cd]is.*050'))[1] as oic_at_050,
            min(log_updated_at) filter (where product_status ~*  '^[cd]is.*070') pass_070_date,
            (array_agg(updated_by_oic order by log_updated_at) filter (where product_status ~*  '^[cd]is.*070'))[1] as oic_at_070
        FROM
            consolidated_cis_lead_logs
        WHERE
            user_id = rl.user_id 
            and log_updated_at >= rl.profile_date
    ) cll ON TRUE